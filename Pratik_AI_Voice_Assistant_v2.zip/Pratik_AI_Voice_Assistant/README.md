# PRATIK AI Voice Assistant  (v2.0 - advanced)

A native Android voice assistant that understands **Nepali (Devanagari), romanized Nepali and English**, speaks back,
controls the phone, and can optionally use an LLM as its "brain" - with a safety gate between the brain and the phone.

```
Mic -> Speech-to-Text -> Wake word -> Parser --(not understood)--> LLM planner (optional)
                                          \                           /
                                           v                         v
                                         Safety Gate  (allow / confirm / block)
                                                 |
                                         Android action -> Text-to-Speech
```

## What's new compared to v1

| Area | v1 | v2 |
|---|---|---|
| Listening | one recognizer, restarts blindly, hears its own voice | error back-off, watchdog, mic paused while speaking, live partial transcript |
| Trigger | every sentence is a command ("mother" anywhere -> call) | **wake word** ("Hey Pratik"), follow-up window, push-to-talk |
| Understanding | 6 hard-coded `contains()` rules | multilingual intent parser (English / roman Nepali / Devanagari), slot filling ("kaslai call garne?") |
| Contacts | scans for "mother" only | any contact, relations (aama/mom/buwa/didi...), your own nicknames, emoji-safe, fuzzy match, ambiguity question |
| Apps | Facebook only | **any installed app** by name (incl. Devanagari names) |
| Actions | call, home, back, Facebook | call, SMS, open app, web search, YouTube, navigation, alarm, timer, torch, volume, Wi-Fi/Bluetooth/location panels, time/date/battery, screenshot, lock, recents, notifications, tap/scroll/type on screen, read/describe screen |
| AI | none | optional OpenAI-compatible / Gemini / Claude brain, answers questions and proposes allow-listed actions |
| Safety | reply text only | real `SafetyGate`: SMS + emergency calls + risky buttons need "yes", deletion is blocked, passwords never typed/read |
| UI | 3 buttons | live chat log, status, typed commands, quick chips, full Settings screen with permission checklist |
| Bugs fixed | | see below |

### Bugs fixed from v1
* Android 11+ needs `<queries>`; without it speech recognition, TTS and "is Facebook installed?" all failed.
* The microphone service started before the permission dialog finished (crash on Android 14).
* Notification permission (Android 13+) and edge-to-edge insets (Android 15) were not handled.
* Background app launches are blocked on Android 10+; v2 uses the accessibility service / overlay permission and falls back to a "tap to open" notification.
* `allowBackup` is now off so the API key can never be backed up.

## Build

1. Open the folder in **Android Studio Ladybug (2024.2) or newer** (JDK 17, Gradle 8.9 is set in `gradle/wrapper`).
2. Let Gradle sync, then Run `app` on a real phone (emulators have no microphone quality / Nepali voices).
3. Optional: `./gradlew test` runs the parser unit tests (`app/src/test`).

## Get an APK

**Android Studio:** Build -> Build Bundle(s) / APK(s) -> Build APK(s). File: `app/build/outputs/apk/debug/app-debug.apk`.

**No Android Studio (GitHub):** create a new GitHub repo, upload this whole folder, open the *Actions* tab -> *Build APK* -> Run workflow.
When it finishes, download `PratikAI-debug-apk` from the run page, unzip it and install `app-debug.apk`
(allow "Install unknown apps" on the phone). The debug APK is auto-signed, so it installs directly.

## First run

Tap **START ASSISTANT**, then **SETTINGS** and turn everything in the checklist to `[OK]`:

1. Microphone, Contacts, Phone calls (required for calling), SMS (optional), Notifications
2. **Phone control** (Accessibility) - needed for Back/Home, tap, scroll, type, screen reading
3. **Display over other apps** - makes opening apps from the background reliable
4. **Battery: don't optimize** - keeps the listener alive on aggressive OEM ROMs

## Talking to it

Say the wake word first: **"Pratik, ..."** (or "Hey Pratik"). After it answers you have ~8 s to keep talking without repeating it.
You can also press **SPEAK NOW** (app or notification) or type in the app.

| Say | Does |
|---|---|
| "Aama lai call gara" / "call mom" / "आमा लाई कल गर" | calls the matching contact |
| "Ramesh lai message pathau" -> "ma aauchu" -> "haju" | asks for the text, reads it back, sends after "yes" |
| "Facebook khola" / "फेसबुक खोल" / "open camera" | opens any installed app |
| "5 minute ko timer lagau" / "alarm 6:30 am" | timer / alarm |
| "torch on" / "volume 50 percent" / "mute" | torch / volume |
| "Thamel jane bato dekhau" / "navigate to Pokhara" | Google Maps route |
| "youtube ma lofi song chalau" / "search best laptop" | YouTube / Google |
| "back ja", "home ja", "take a screenshot", "lock the phone", "scroll down", "click Send", "type hello" | phone control |
| "read the screen" / "screen ma ke cha" | reads / summarizes what is on screen |
| "time kati bajyo", "battery kati cha", "aaja ko date" | information |
| "language nepali gara" / "language english" | switches voice language |
| "Who created you?" | "Pratik Upadhayay sir le banaunu bhayeko ho." Refuses to credit anyone else. |

Nicknames: if a contact is saved as "Mummy" and you say "aama", it works out of the box; for anything else add a nickname in Settings.

## AI brain (optional)

Settings -> *AI brain*: enable, pick a provider, paste your API key and model name, press **TEST**.
Anything the rules do not understand is sent to the model (and only then). The model may answer in text or propose one action from a fixed list;
the action still passes through the SafetyGate, and calls/messages proposed by the model are always confirmed. Without a key, unknown questions fall back to a Google search.
Endpoints must be `https://`.

## Safety design

* No wake word -> ambient speech is ignored (can be turned off in Settings, not recommended).
* `SafetyGate`: **BLOCK** delete/uninstall/reset (assistant explains how to do it manually); **CONFIRM** SMS, emergency numbers (Nepal 100 / 101 / 102), optional every call, buttons like Send/Pay/Buy/Install; everything else allowed.
* Accessibility layer never types into or reads password fields and only acts when asked.
* Screen text sent to the LLM (describe screen) is treated as untrusted data and never produces actions.

## Project layout

```
Text.kt / Lexicon.kt      normalization, language detection, word lists (EN / roman-NE / Devanagari)
IntentParser.kt           text -> Command   (pure Kotlin, unit-tested)
Command.kt                the closed list of things the assistant can do
SafetyGate.kt             allow / confirm / block
AssistantBrain.kt         wake word, follow-up questions, confirmations, LLM fallback, replies
PhoneController.kt        performs actions (calls, SMS, apps, alarms, torch, volume, ...)
Resolvers.kt              app + contact matching
AssistantAccessibilityService.kt   tap / scroll / type / read / global buttons
LlmClient.kt              OpenAI-compatible, Gemini, Claude
SpeechIn.kt / SpeechOut.kt         resilient STT loop / TTS with audio focus
AssistantService.kt       foreground microphone service wiring it all together
MainActivity.kt / SettingsActivity.kt / Ui.kt / Bus.kt / Settings.kt
```

## Known limits

* Android does not let apps flip Wi-Fi / Bluetooth / airplane mode any more, so the assistant opens the right panel instead.
* Google's recognizer sometimes beeps when it restarts, and needs internet unless an offline Nepali pack is installed.
* Romanized Nepali is spoken with an English-India voice when no Nepali TTS voice with Latin-script support is installed.
* Devanagari contact spellings from speech may not match Latin contact names - add a nickname.
* The service does not auto-start on boot (Android 14 forbids starting a microphone service from `BOOT_COMPLETED`).

## License

MIT (see `LICENSE`).
