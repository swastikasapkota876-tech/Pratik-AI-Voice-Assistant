package com.pratik.aiassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground microphone service. Wires together:
 * SpeechIn (microphone) -> AssistantBrain (understand / safety / act) -> SpeechOut (voice).
 */
class AssistantService : Service(), Speaker, SpeechIn.Callback {

    companion object {
        const val ACTION_STOP = "com.pratik.aiassistant.action.STOP"
        const val ACTION_LISTEN_NOW = "com.pratik.aiassistant.action.LISTEN_NOW"
        const val ACTION_TEXT = "com.pratik.aiassistant.action.TEXT"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "pratik_ai"
        private const val NOTIF_ID = 77

        @Volatile
        var running = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AssistantService::class.java))
        }

        /** Runs a typed command through the running assistant (used by the app UI). */
        fun sendText(ctx: Context, text: String) {
            ctx.startService(Intent(ctx, AssistantService::class.java).setAction(ACTION_TEXT).putExtra(EXTRA_TEXT, text))
        }

        fun listenNow(ctx: Context) {
            ctx.startService(Intent(ctx, AssistantService::class.java).setAction(ACTION_LISTEN_NOW))
        }
    }

    private lateinit var settings: AppSettings
    private lateinit var out: SpeechOut
    private lateinit var input: SpeechIn
    private lateinit var brain: AssistantBrain
    private var stopAfterSpeech = false

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        createChannel()
        try {
            val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
        } catch (e: Exception) {
            // Microphone permission missing or Android refused a background start.
            stopSelf()
            return
        }
        running = true
        AssistantBus.setState(AssistantState.IDLE)

        out = SpeechOut(this, settings, { onSpeakStart() }, { onSpeakDone() })
        brain = AssistantBrain(this, settings, this)
        input = SpeechIn(this, settings, this)
        input.enable()

        val lang = if (settings.languageMode == "en") Lang.EN else Lang.NE
        val hint = if (settings.wakeWordEnabled) {
            t(lang, " Say \"${settings.wakeWord}\" and then your command.", " Malai bolauna '${settings.wakeWord}' bhannuhos.")
        } else ""
        val hello = t(
            lang,
            "Hello sir. Pratik AI is ready.",
            "Namaste sir. Pratik AI ready cha. Hajur j bhannu huncha, ma bujhne kosis garchu."
        )
        AssistantBus.chat(false, hello + hint)
        out.speak(hello + hint, lang)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) return START_NOT_STICKY
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN_NOW -> {
                brain.armFor(10_000)
                input.restartNow()
            }
            ACTION_TEXT -> {
                val text = intent?.getStringExtra(EXTRA_TEXT)
                if (!text.isNullOrBlank()) brain.onTyped(text)
            }
        }
        return START_NOT_STICKY
    }

    // ---- Speaker (called by the brain) --------------------------------------------------------------------------

    override fun say(text: String, lang: Lang) {
        if (running) out.speak(text, lang)
    }

    override fun stopAssistant() {
        stopAfterSpeech = true
        if (!out.isSpeaking()) stopSelf()
    }

    override fun onSettingsChanged() {
        if (running) input.restartNow()
    }

    // ---- SpeechIn.Callback --------------------------------------------------------------------------------------

    override fun onResults(alternatives: List<String>) {
        brain.onSpeech(alternatives)
    }

    override fun onFatal(message: String) {
        AssistantBus.chat(false, message)
        stopAfterSpeech = true
        out.speak(message, Lang.NE)
    }

    override fun onNotice(message: String) {
        AssistantBus.chat(false, message)
        out.speak(message, Lang.NE)
    }

    // ---- speech state -------------------------------------------------------------------------------------------

    private fun onSpeakStart() {
        input.pause()
        AssistantBus.setState(AssistantState.SPEAKING)
    }

    private fun onSpeakDone() {
        if (stopAfterSpeech) {
            stopSelf()
            return
        }
        brain.markActive()
        AssistantBus.setState(AssistantState.LISTENING)
        input.resume(400)
    }

    // ---- lifecycle ----------------------------------------------------------------------------------------------

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        if (this::input.isInitialized) input.destroy()
        if (this::brain.isInitialized) brain.shutdown()
        if (this::out.isInitialized) out.shutdown()
        AssistantBus.setState(AssistantState.OFF)
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Pratik AI", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val speak = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_LISTEN_NOW), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val hint = if (settings.wakeWordEnabled) "Say \"${settings.wakeWord}\" to give a command" else "Listening for commands"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pratik AI Assistant")
            .setContentText(hint)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Speak now", speak)
            .addAction(0, "Stop", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }
}
