package com.pratik.aiassistant

/** Word lists for English, romanized Nepali and Devanagari Nepali. All entries are already normalized (lowercase). */
object Lex {
    val stop: Set<String> = setOf(
        "please", "plz", "pls", "the", "a", "an", "to", "my", "me", "for", "now", "app", "apps", "application",
        "hey", "ok", "okay", "can", "you", "could", "would", "will", "kindly", "just", "it", "this", "i",
        "want", "need", "like", "wanna", "of",
        "lai", "laai", "ko", "ka", "ki", "ma", "le", "ni", "ta", "hai", "ho", "hajur", "sir", "mero", "meri",
        "yo", "tyo", "ra", "aba", "ali",
        "\u0932\u093E\u0908", "\u0915\u094B", "\u0915\u093E", "\u0915\u0940", "\u092E\u093E", "\u0932\u0947",
        "\u0928\u093F", "\u0924", "\u0939\u0948", "\u0939\u094B", "\u0939\u091C\u0941\u0930", "\u0938\u0930",
        "\u092E\u0947\u0930\u094B", "\u092E\u0947\u0930\u0940", "\u092F\u094B", "\u0924\u094D\u092F\u094B",
        "\u0930", "\u0915\u0943\u092A\u092F\u093E", "\u0905\u092C"
    )

    /** Nepali "do it" verb forms: gara, garnu, garideu ... */
    val nepaliDo: Set<String> = setOf(
        "gara", "garnu", "garnus", "garideu", "garidinu", "garidinus", "garau", "garaideu", "garidenu",
        "garnuhos", "garidinuhos",
        "\u0917\u0930", "\u0917\u0930\u094D\u0928\u0941", "\u0917\u0930\u094D\u0928\u0941\u0938\u094D",
        "\u0917\u0930\u093F\u0926\u0947\u0909", "\u0917\u0930\u093F\u0926\u093F\u0928\u0941",
        "\u0917\u0930\u093F\u0926\u093F\u0928\u0941\u0938\u094D", "\u0917\u0930\u093E\u0909",
        "\u0917\u0930\u094D\u0928\u0941\u0939\u094B\u0938\u094D", "\u0917\u0930\u093F\u0926\u093F\u0928\u0941\u0939\u094B\u0938\u094D"
    )

    // ---- verbs -------------------------------------------------------------------------------------------------
    val callVerbs: Set<String> = setOf("call", "dial", "ring")
    /** "phone"/"kal" are only a call verb when combined with a Nepali do-verb ("aama lai phone gara"). */
    val weakCallVerbs: Set<String> = setOf("phone", "\u092B\u094B\u0928", "\u0915\u0932")
    val lagau: Set<String> = setOf(
        "lagau", "lagaideu", "lagaidinu", "\u0932\u0917\u093E\u0909", "\u0932\u0917\u093E\u0907\u0926\u0947\u0909",
        "\u0932\u0917\u093E\u0909\u0928\u0941"
    )
    val talkWords: Set<String> = setOf(
        "talk", "speak", "with", "sanga", "kura", "\u0938\u0901\u0917", "\u0938\u0919\u094D\u0917", "\u0915\u0941\u0930\u093E"
    )
    val openVerbs: Set<String> = setOf(
        "open", "launch", "start", "run",
        "khola", "khol", "kholnu", "kholnus", "kholideu", "kholidinu", "kholidinus", "kholdeu", "kholdinu", "kholdinus",
        "chalau", "chalaideu", "chalaunu",
        "\u0916\u094B\u0932", "\u0916\u094B\u0932\u093F\u0926\u0947\u0909", "\u0916\u094B\u0932\u093F\u0926\u093F\u0928\u0941",
        "\u0916\u094B\u0932\u093F\u0926\u093F\u0928\u0941\u0938\u094D", "\u0916\u094B\u0932\u094D\u0928\u0941",
        "\u0916\u094B\u0932\u094D\u0928\u0941\u0938\u094D", "\u091A\u0932\u093E\u0909", "\u091A\u0932\u093E\u0907\u0926\u0947\u0909"
    )
    val searchVerbs: Set<String> = setOf(
        "search", "google", "lookup", "browse", "khoj", "khoja", "khojnu", "khojideu", "khojidinu",
        "\u0916\u094B\u091C", "\u0916\u094B\u091C\u094D\u0928\u0941", "\u0916\u094B\u091C\u093F\u0926\u0947\u0909",
        "\u0938\u0930\u094D\u091A", "\u0938\u0930\u094D\u091A\u0917\u0930"
    )
    val searchNoise: Set<String> = searchVerbs + nepaliDo + setOf(
        "for", "about", "please", "plz", "pls", "hey", "ok", "okay", "google", "web", "internet", "online",
        "ma", "ko", "barema", "bare", "lai", "\u092E\u093E", "\u0915\u094B", "\u092C\u093E\u0930\u0947\u092E\u093E",
        "\u0932\u093E\u0908"
    )
    val clickVerbs: Set<String> = setOf(
        "click", "tap", "press", "select", "thich", "thichnu", "thicha", "thichideu",
        "\u0925\u093F\u091A", "\u0925\u093F\u091A\u094D\u0928\u0941", "\u0925\u093F\u091A\u093F\u0926\u0947\u0909",
        "\u0915\u094D\u0932\u093F\u0915", "\u091F\u094D\u092F\u093E\u092A"
    )
    val typeVerbsEn: Set<String> = setOf("type", "write", "dictate")
    val typeVerbsNe: Set<String> = setOf(
        "likha", "lekha", "likhnu", "lekhnu", "likhideu", "\u0932\u0947\u0916", "\u0932\u0947\u0916\u094D\u0928\u0941",
        "\u0932\u0947\u0916\u093F\u0926\u0947\u0909", "\u0932\u093F\u0916", "\u0932\u093F\u0916\u093F\u0926\u0947\u0909"
    )
    val sendVerbs: Set<String> = setOf(
        "send", "write", "compose", "pathau", "pathaideu", "pathaidinu", "pathaidinus", "pathaunu",
        "\u092A\u0920\u093E\u0909", "\u092A\u0920\u093E\u0907\u0926\u0947\u0909", "\u092A\u0920\u093E\u0907\u0926\u093F\u0928\u0941",
        "\u092A\u0920\u093E\u0907\u0926\u093F\u0928\u0941\u0938\u094D"
    )
    val smsNouns: Set<String> = setOf(
        "sms", "text", "message", "messages", "msg", "sandesh",
        "\u0938\u0928\u094D\u0926\u0947\u0936", "\u092E\u0947\u0938\u0947\u091C", "\u092E\u094D\u092F\u093E\u0938\u0947\u091C",
        "\u092E\u0948\u0938\u0947\u091C", "\u091F\u0947\u0915\u094D\u0938\u094D\u091F"
    )
    val sayWords: Set<String> = setOf(
        "saying", "say", "says", "tell", "telling", "bhanera", "bhani", "\u092D\u0928\u0947\u0930", "\u092D\u0928\u0940"
    )
    val sayWordsNe: Set<String> = setOf("bhanera", "bhani", "\u092D\u0928\u0947\u0930", "\u092D\u0928\u0940")
    val playVerbs: Set<String> = setOf(
        "play", "bajau", "bajaideu", "bajaidinu", "\u092C\u091C\u093E\u0909", "\u092C\u091C\u093E\u0907\u0926\u0947\u0909"
    )
    val youtubeWords: Set<String> = setOf(
        "youtube", "\u092F\u0942\u091F\u094D\u092F\u0941\u092C", "\u092F\u0941\u091F\u094D\u092F\u0941\u092C",
        "\u092F\u0942\u091F\u094D\u092F\u0942\u092C", "\u092F\u0941\u091F\u0941\u092C"
    )
    val navWords: Set<String> = setOf(
        "navigate", "directions", "direction", "route", "navigation", "baato", "bato", "rasta", "raasta",
        "\u0928\u0947\u092D\u093F\u0917\u0947\u091F", "\u0930\u0941\u091F", "\u092C\u093E\u091F\u094B", "\u0930\u0938\u094D\u0924\u093E"
    )
    val navNoise: Set<String> = navWords + nepaliDo + setOf(
        "show", "give", "get", "take", "me", "how", "to", "go", "dekhau", "dekhaideu", "jana", "jane", "jaane",
        "\u0926\u0947\u0916\u093E\u0909", "\u0926\u0947\u0916\u093E\u0907\u0926\u0947\u0909", "\u091C\u093E\u0928", "\u091C\u093E\u0928\u0947",
        "ko", "ka", "lai", "ma", "\u0915\u094B", "\u0932\u093E\u0908", "\u092E\u093E", "please", "the", "a", "my", "hey", "ok", "okay"
    )

    // ---- misc word sets ----------------------------------------------------------------------------------------
    val languageWords: Set<String> = setOf("language", "bhasa", "bhasha", "\u092D\u093E\u0937\u093E", "lang")
    val nepaliNames: Set<String> = setOf("nepali", "\u0928\u0947\u092A\u093E\u0932\u0940", "nepal")
    val englishNames: Set<String> = setOf(
        "english", "angreji", "inglish", "\u0905\u0902\u0917\u094D\u0930\u0947\u091C\u0940", "\u0905\u0919\u094D\u0917\u094D\u0930\u0947\u091C\u0940"
    )
    val autoNames: Set<String> = setOf("auto", "automatic", "both", "\u0926\u0941\u092C\u0948")
    val deleteWords: Set<String> = setOf(
        "delete", "erase", "wipe", "format", "uninstall", "factory", "hatau", "hatai", "hataideu", "metau", "mete",
        "\u0921\u093F\u0932\u093F\u091F", "\u0939\u091F\u093E\u0909", "\u0939\u091F\u093E\u0907\u0926\u0947\u0909", "\u0939\u091F\u093E\u0907",
        "\u092E\u0947\u091F", "\u092E\u0947\u091F\u093E\u0909", "\u092E\u0947\u091F\u093E\u0907\u0926\u0947\u0909",
        "\u0905\u0928\u0907\u0928\u094D\u0938\u094D\u091F\u0932"
    )
    val importantWords: Set<String> = setOf(
        "important", "imp", "mahatwapurna", "mahattwapurna", "jaruri", "zaruri",
        "\u092E\u0939\u0924\u094D\u0924\u094D\u0935\u092A\u0942\u0930\u094D\u0923", "\u092E\u0939\u0924\u094D\u0935\u092A\u0942\u0930\u094D\u0923",
        "\u091C\u0930\u0941\u0930\u0940"
    )
    val offWords: Set<String> = setOf(
        "off", "band", "nibha", "nibhau", "nibhaideu", "nibhaidinu", "disable", "stop",
        "\u092C\u0928\u094D\u0926", "\u0928\u093F\u092D\u093E\u0909", "\u0928\u093F\u092D\u093E\u0907\u0926\u0947\u0909"
    )
    val onWords: Set<String> = setOf("on", "enable", "bala", "balau", "baaldeu", "\u092C\u093E\u0932", "\u092C\u093E\u0932\u093F\u0926\u0947\u0909")
    val onOff: Set<String> = offWords + onWords
    val upWords: Set<String> = setOf(
        "up", "increase", "raise", "louder", "loud", "badhau", "badha", "badhaideu", "high",
        "\u092C\u0922\u093E\u0909", "\u092C\u0922\u093E\u0907\u0926\u0947\u0909", "\u092C\u0922\u094D\u0924\u093E"
    )
    val downWords: Set<String> = setOf(
        "down", "decrease", "lower", "reduce", "quieter", "kam", "kamau", "ghatau", "ghataideu", "low", "halka",
        "\u0918\u091F\u093E\u0909", "\u0918\u091F\u093E\u0907\u0926\u0947\u0909", "\u0915\u092E"
    )
    val maxWords: Set<String> = setOf("max", "maximum", "full", "pura")
    val flashWords: Set<String> = setOf(
        "flashlight", "torch", "flash", "\u091F\u0930\u094D\u091A",
        "\u092B\u094D\u0932\u094D\u092F\u093E\u0938\u0932\u093E\u0907\u091F", "\u092B\u094D\u0932\u094D\u092F\u093E\u0938"
    )
    val wifiWords: Set<String> = setOf("wifi", "\u0935\u093E\u0907\u092B\u093E\u0907", "\u0935\u093E\u0908\u092B\u093E\u0908", "internet", "\u0907\u0928\u094D\u091F\u0930\u0928\u0947\u091F")
    val bluetoothWords: Set<String> = setOf("bluetooth", "\u092C\u094D\u0932\u0941\u091F\u0941\u0925", "\u092C\u094D\u0932\u0942\u091F\u0942\u0925")
    val locationWords: Set<String> = setOf("location", "gps", "\u0932\u094B\u0915\u0947\u0938\u0928")
    val hotspotWords: Set<String> = setOf("hotspot", "\u0939\u091F\u0938\u094D\u092A\u091F")
    val yesWords: Set<String> = setOf(
        "yes", "yeah", "yep", "yup", "sure", "ok", "okay", "confirm", "haju", "hajur", "huncha", "hunchha", "ho",
        "garnus", "garidinus", "thik", "\u0939\u0941\u0928\u094D\u091B", "\u0939\u091C\u0941\u0930", "\u0939\u094B",
        "\u0917\u0930\u094D\u0928\u0941\u0938\u094D", "\u0917\u0930\u093F\u0926\u093F\u0928\u0941\u0938\u094D", "\u0920\u093F\u0915"
    )
    val noWords: Set<String> = setOf(
        "no", "nope", "cancel", "stop", "dont", "don't", "hoina", "hudaina", "nagara", "nagarnus", "radd", "rahos",
        "\u0939\u094B\u0907\u0928", "\u0939\u0941\u0901\u0926\u0948\u0928", "\u0939\u0941\u0926\u0948\u0928", "\u0928\u0917\u0930",
        "\u0928\u0917\u0930\u094D\u0928\u0941\u0938\u094D", "\u0930\u0926\u094D\u0926"
    )

    // ---- numbers & time ----------------------------------------------------------------------------------------
    val numberWords: Map<String, Int> = mapOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8,
        "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "fifteen" to 15, "twenty" to 20, "thirty" to 30,
        "forty" to 40, "fifty" to 50, "sixty" to 60, "a" to 1, "an" to 1,
        "ek" to 1, "dui" to 2, "tin" to 3, "teen" to 3, "char" to 4, "panch" to 5, "paanch" to 5, "chha" to 6,
        "saat" to 7, "sat" to 7, "aath" to 8, "nau" to 9, "das" to 10, "eghar" to 11, "eghara" to 11, "bara" to 12,
        "barha" to 12, "pandra" to 15, "bis" to 20, "tis" to 30, "chalis" to 40, "pachas" to 50, "saathi" to 60,
        "\u090F\u0915" to 1, "\u0926\u0941\u0908" to 2, "\u0926\u0941\u0907" to 2, "\u0924\u0940\u0928" to 3,
        "\u091A\u093E\u0930" to 4, "\u092A\u093E\u0901\u091A" to 5, "\u092A\u093E\u091A" to 5, "\u091B" to 6,
        "\u0938\u093E\u0924" to 7, "\u0906\u0920" to 8, "\u0928\u094C" to 9, "\u0926\u0936" to 10, "\u0926\u0938" to 10,
        "\u090F\u0918\u093E\u0930" to 11, "\u092C\u093E\u0939\u094D\u0930" to 12, "\u092A\u0928\u094D\u0927\u094D\u0930" to 15,
        "\u092C\u0940\u0938" to 20, "\u0924\u0940\u0938" to 30, "\u091A\u093E\u0932\u0940\u0938" to 40, "\u092A\u091A\u093E\u0938" to 50,
        "\u0938\u093E\u0920\u0940" to 60
    )
    fun numberValue(w: String): Int? = w.toIntOrNull() ?: numberWords[w]

    val unitSeconds: Map<String, Int> = mapOf(
        "second" to 1, "seconds" to 1, "sec" to 1, "secs" to 1, "sekend" to 1, "sekent" to 1,
        "\u0938\u0947\u0915\u0947\u0928\u094D\u0921" to 1, "\u0938\u0947\u0915\u0947\u0923\u094D\u0921" to 1,
        "minute" to 60, "minutes" to 60, "min" to 60, "mins" to 60, "minet" to 60,
        "\u092E\u093F\u0928\u0947\u091F" to 60, "\u092E\u093F\u0928\u091F" to 60,
        "hour" to 3600, "hours" to 3600, "hr" to 3600, "hrs" to 3600, "ghanta" to 3600, "ghantaa" to 3600,
        "\u0918\u0923\u094D\u091F\u093E" to 3600, "\u0918\u0928\u094D\u091F\u093E" to 3600
    )
    val halfWords: Set<String> = setOf("half", "aadha", "adha", "\u0906\u0927\u093E")
    val clockMarkers: Set<String> = setOf("am", "pm", "baje", "\u092C\u091C\u0947", "oclock", "o'clock")
    val morningWords: Set<String> = setOf("morning", "subah", "bihana", "bihani", "\u092C\u093F\u0939\u093E\u0928")
    val eveningWords: Set<String> = setOf(
        "evening", "night", "tonight", "afternoon", "beluka", "belukaa", "sanjh", "raat", "rat", "diuso", "dinma",
        "\u092C\u0947\u0932\u0941\u0915\u093E", "\u0938\u093E\u0901\u091D", "\u0938\u093E\u0902\u091D", "\u0930\u093E\u0924",
        "\u0930\u093E\u0924\u093F", "\u0926\u093F\u0909\u0901\u0938\u094B"
    )
    val sadhe: Set<String> = setOf("sadhe", "\u0938\u093E\u0922\u0947", "\u0938\u093E\u0922\u0947")

    // ---- people ------------------------------------------------------------------------------------------------
    val relations: List<List<String>> = listOf(
        listOf("mother", "mom", "mommy", "mummy", "mum", "maa", "aama", "aamaa", "ama", "\u0906\u092E\u093E", "\u0906\u092E\u093E\u0901", "\u092E\u092E\u0940", "\u092E\u092E\u094D\u092E\u0940"),
        listOf("father", "dad", "daddy", "papa", "baba", "buwa", "buba", "\u092C\u0941\u0935\u093E", "\u092C\u0941\u092C\u093E", "\u092C\u093E\u092C\u093E", "\u092A\u093E\u092A\u093E", "\u092A\u093F\u0924\u093E"),
        listOf("sister", "didi", "bahini", "\u0926\u093F\u0926\u0940", "\u092C\u0939\u093F\u0928\u0940"),
        listOf("brother", "dai", "bhai", "\u0926\u093E\u0907", "\u0926\u093E\u0908", "\u092D\u093E\u0907", "\u092D\u093E\u0908")
    )
    fun relationGroup(norm: String): List<String>? = relations.firstOrNull { norm in it }

    /** Nepal emergency numbers (always confirmed before dialing). */
    val emergency: Map<String, String> = mapOf(
        "police" to "100", "pulis" to "100", "\u092A\u094D\u0930\u0939\u0930\u0940" to "100", "\u092A\u0941\u0932\u093F\u0938" to "100",
        "ambulance" to "102", "\u090F\u092E\u094D\u092C\u0941\u0932\u0947\u0928\u094D\u0938" to "102",
        "damkal" to "101", "\u0926\u092E\u0915\u0932" to "101", "fire brigade" to "101"
    )
    fun emergencyNumber(target: String): String? = emergency[Norm.normalize(target)]

    // ---- apps --------------------------------------------------------------------------------------------------
    /** spoken / transliterated name -> label keyword(s) ("a|b" = try a then b). */
    val appAliases: Map<String, String> = mapOf(
        "fb" to "facebook", "\u092B\u0947\u0938\u092C\u0941\u0915" to "facebook", "\u092B\u0947\u0938\u092C\u0942\u0915" to "facebook",
        "\u092E\u0947\u0938\u0947\u0928\u094D\u091C\u0930" to "messenger", "\u092E\u0947\u0938\u0947\u0902\u091C\u0930" to "messenger",
        "\u0935\u094D\u0939\u093E\u091F\u094D\u0938\u090F\u092A" to "whatsapp", "\u0935\u093E\u091F\u094D\u0938\u090F\u092A" to "whatsapp",
        "\u0935\u094D\u0939\u093E\u091F\u094D\u0938\u0905\u092A" to "whatsapp", "\u0935\u093E\u091F\u094D\u0938\u0905\u092A" to "whatsapp",
        "whats app" to "whatsapp",
        "\u092F\u0942\u091F\u094D\u092F\u0942\u092C" to "youtube", "\u092F\u0941\u091F\u094D\u092F\u0941\u092C" to "youtube",
        "insta" to "instagram", "\u0907\u0928\u094D\u0938\u094D\u091F\u093E\u0917\u094D\u0930\u093E\u092E" to "instagram", "\u0907\u0928\u094D\u0938\u094D\u091F\u093E" to "instagram",
        "\u091F\u093F\u0915\u091F\u0915" to "tiktok", "\u0915\u094D\u0930\u094B\u092E" to "chrome", "\u091C\u0940\u092E\u0947\u0932" to "gmail",
        "\u0917\u0941\u0917\u0932" to "google", "\u0917\u0942\u0917\u0932" to "google",
        "maps" to "maps", "map" to "maps", "\u092E\u094D\u092F\u093E\u092A" to "maps", "\u092E\u094D\u092F\u093E\u092A\u094D\u0938" to "maps",
        "\u0915\u094D\u092F\u093E\u092E\u0947\u0930\u093E" to "camera", "\u0915\u094D\u092F\u093E\u092E\u0930\u093E" to "camera",
        "\u0917\u094D\u092F\u093E\u0932\u0947\u0930\u0940" to "gallery|photos", "\u0917\u094D\u092F\u093E\u0932\u0930\u0940" to "gallery|photos",
        "gallery" to "gallery|photos", "photos" to "photos|gallery",
        "calc" to "calculator", "\u0915\u094D\u092F\u093E\u0932\u094D\u0915\u0941\u0932\u0947\u091F\u0930" to "calculator",
        "\u0938\u0947\u091F\u093F\u0919" to "settings", "\u0938\u0947\u091F\u093F\u0919\u094D\u0938" to "settings", "\u0938\u0947\u091F\u093F\u0902\u0917" to "settings",
        "setting" to "settings", "\u0918\u0921\u0940" to "clock", "\u0915\u094D\u0932\u0915" to "clock",
        "\u0915\u094D\u092F\u093E\u0932\u0947\u0928\u094D\u0921\u0930" to "calendar",
        "\u0915\u0928\u094D\u091F\u094D\u092F\u093E\u0915\u094D\u091F" to "contacts", "\u0915\u0928\u094D\u091F\u094D\u092F\u093E\u0915\u094D\u091F\u094D\u0938" to "contacts",
        "dialer" to "phone|dialer", "\u0921\u093E\u092F\u0932\u0930" to "phone|dialer",
        "music" to "music|spotify|youtube music", "\u092E\u094D\u092F\u0941\u091C\u093F\u0915" to "music|spotify",
        "\u0907\u0938\u0947\u0935\u093E" to "esewa", "\u0908\u0938\u0947\u0935\u093E" to "esewa", "\u0916\u0932\u094D\u0924\u0940" to "khalti",
        "\u0939\u093E\u092E\u094D\u0930\u094B \u092A\u093E\u0924\u094D\u0930\u094B" to "hamro patro", "\u092A\u093E\u0924\u094D\u0930\u094B" to "hamro patro",
        "\u092D\u093E\u0907\u092C\u0930" to "viber", "\u091F\u0947\u0932\u093F\u0917\u094D\u0930\u093E\u092E" to "telegram",
        "\u0938\u094D\u0928\u094D\u092F\u093E\u092A\u091A\u093E\u091F" to "snapchat", "\u091F\u094D\u0935\u093F\u091F\u0930" to "twitter|x",
        "\u092A\u094D\u0932\u0947 \u0938\u094D\u091F\u094B\u0930" to "play store", "playstore" to "play store",
        "\u092B\u093E\u0907\u0932" to "files", "file manager" to "files",
        "\u0928\u094B\u091F" to "notes|keep", "\u0907\u092E\u094B" to "imo", "\u0928\u0947\u091F\u092B\u094D\u0932\u093F\u0915\u094D\u0938" to "netflix",
        "\u0938\u094D\u092A\u094B\u091F\u093F\u092B\u093E\u0907" to "spotify", "\u092A\u0920\u093E\u0913" to "pathao"
    )

    /** Well known package names (tried first when installed). */
    val appPackages: Map<String, List<String>> = mapOf(
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "messenger" to listOf("com.facebook.orca"),
        "whatsapp" to listOf("com.whatsapp"),
        "youtube" to listOf("com.google.android.youtube"),
        "instagram" to listOf("com.instagram.android"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "chrome" to listOf("com.android.chrome"),
        "gmail" to listOf("com.google.android.gm"),
        "maps" to listOf("com.google.android.apps.maps"),
        "telegram" to listOf("org.telegram.messenger"),
        "viber" to listOf("com.viber.voip"),
        "spotify" to listOf("com.spotify.music"),
        "netflix" to listOf("com.netflix.mediaclient"),
        "snapchat" to listOf("com.snapchat.android"),
        "play store" to listOf("com.android.vending")
    )

    /** Single words that, said alone, mean "open this app". */
    val knownAppWords: Set<String> by lazy {
        val s = HashSet<String>()
        s.addAll(appAliases.keys)
        s.addAll(appPackages.keys)
        for (v in appAliases.values) s.addAll(v.split("|"))
        s.removeAll(setOf("maps", "map", "music", "photos", "gallery", "files", "settings", "setting"))
        s
    }

    // ---- persona -----------------------------------------------------------------------------------------------
    val impersonation: List<String> = listOf(
        " i created you ", " i made you ", " i built you ", " i developed you ", " maile timilai banaye ",
        " maile timilai banayeko ", " maile banayeko ", " maile banaeko ", " mero ai ",
        " \u0924\u093F\u092E\u0940\u0932\u093E\u0908 \u092E\u0948\u0932\u0947 \u092C\u0928\u093E\u090F\u0915\u094B ",
        " \u092E\u0948\u0932\u0947 \u0924\u093F\u092E\u0940\u0932\u093E\u0908 \u092C\u0928\u093E\u090F\u0915\u094B ",
        " \u092E\u0948\u0932\u0947 \u092C\u0928\u093E\u090F\u0915\u094B "
    )
}
