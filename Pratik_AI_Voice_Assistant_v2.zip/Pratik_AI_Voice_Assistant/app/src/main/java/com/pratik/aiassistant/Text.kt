package com.pratik.aiassistant

enum class Lang { EN, NE }

/** Picks the English or (romanized) Nepali variant of a reply. */
fun t(lang: Lang, en: String, ne: String): String = if (lang == Lang.NE) ne else en

/** A token: [raw] keeps the user's casing (for dictation), [norm] is the normalized form used for matching. */
data class Tok(val raw: String, val norm: String)

object Norm {
    private val punct = Regex("[^\\p{L}\\p{N}\\p{M}\\s:%+']")
    private val dotDigits = Regex("(\\d)\\.(\\d)")
    private val ampm = Regex("\\b([ap])\\.\\s?m\\.?")
    private val digitAmPm = Regex("(\\d)(am|pm)\\b")
    private val looseColon = Regex("(?<!\\d):|:(?!\\d)")
    private val spaces = Regex("\\s+")
    private const val EDGE = ".,!?;:\"'`()[]{}<>|\\/\u2026\u0964-"

    /** Devanagari digits -> ASCII digits. */
    fun digits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(if (c in '\u0966'..'\u096F') ('0' + (c - '\u0966')) else c)
        return sb.toString()
    }

    fun normalize(s: String): String {
        var x = digits(s.lowercase())
        x = x.replace("wi-fi", "wifi").replace("wi fi", "wifi")
        x = ampm.replace(x, "\$1m")
        x = dotDigits.replace(x, "\$1:\$2")
        x = looseColon.replace(x, " saying ")
        x = digitAmPm.replace(x, "\$1 \$2")
        x = punct.replace(x, " ")
        return spaces.replace(x, " ").trim()
    }

    fun words(s: String): List<String> {
        val n = normalize(s)
        return if (n.isEmpty()) emptyList() else n.split(" ")
    }

    fun tokens(s: String): List<Tok> {
        val out = ArrayList<Tok>()
        for (part in s.trim().split(spaces)) {
            if (part.isEmpty()) continue
            val n = normalize(part)
            if (n.isEmpty()) continue
            val pieces = n.split(" ")
            if (pieces.size == 1) out.add(Tok(part.trim { it in EDGE }, n))
            else for (p in pieces) out.add(Tok(p, p))
        }
        return out
    }

    fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    /** True when two words differ by at most one edit (typo / speech-to-text spelling drift). */
    fun near(a: String, b: String): Boolean =
        kotlin.math.abs(a.length - b.length) <= 1 && editDistance(a, b) <= 1
}

object LanguageDetector {
    // Words that are (almost) never English.
    private val strong = setOf(
        "lai", "laai", "gara", "garnu", "garnus", "garideu", "garidinu", "garidinus", "garau", "garnuhos",
        "khola", "kholnu", "kholideu", "kholdeu", "cha", "chha", "chhu", "chu", "chaina", "chhaina",
        "huncha", "hunchha", "hajur", "timilai", "malai", "mero", "timro", "tapai", "tapailai", "ahile",
        "kasari", "kasle", "kaha", "kina", "pathau", "pathaideu", "bhan", "bhana", "bhannu", "bhanera",
        "sunau", "aama", "buwa", "namaste", "dhanyabad", "ramro", "kati", "bajyo", "aaja", "bholi",
        "chalau", "nibhau", "balau", "pachhadi", "pachadi", "thichnu", "thicha", "bajau", "khoja", "khojnu",
        "dekhau", "dekhaideu", "badhau", "ghatau", "sanga", "kura", "baje", "pachi", "hoina", "hudaina"
    )
    // Short words that may also occur in English; two of them are needed.
    private val weak = setOf("ma", "ho", "ra", "ta", "ni", "ke", "k", "ko", "le", "ka", "ki", "pani", "tara", "hos", "hola", "ja", "jau", "band")

    fun hasDevanagari(s: String): Boolean = s.any { it in '\u0900'..'\u097F' }

    fun detect(text: String): Lang {
        if (hasDevanagari(text)) return Lang.NE
        val words = Norm.words(text)
        if (words.any { it in strong }) return Lang.NE
        if (words.count { it in weak } >= 2) return Lang.NE
        return Lang.EN
    }
}
