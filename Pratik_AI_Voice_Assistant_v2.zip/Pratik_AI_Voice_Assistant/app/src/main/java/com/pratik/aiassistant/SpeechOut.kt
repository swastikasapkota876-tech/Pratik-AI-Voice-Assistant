package com.pratik.aiassistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Text-to-speech with: queue until the engine is ready, best-available voice per language (Nepali -> Hindi -> English),
 * audio focus (music ducks while the assistant talks) and start/finish callbacks so the microphone can be paused.
 * Main thread only.
 */
class SpeechOut(
    private val ctx: Context,
    private val settings: AppSettings,
    private val onSpeakStart: () -> Unit,
    private val onSpeakDone: () -> Unit
) : TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayList<Pair<String, Lang>>()
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var tts: TextToSpeech? = null
    private var ready = false
    private var currentId = ""
    private var focus: AudioFocusRequest? = null
    private var speaking = false

    init {
        tts = TextToSpeech(ctx, this)
    }

    override fun onInit(status: Int) {
        val engine = tts ?: return
        ready = status == TextToSpeech.SUCCESS
        if (!ready) return
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                if (utteranceId == currentId) main.post { finished() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == currentId) main.post { finished() }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId == currentId) main.post { finished() }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                if (utteranceId == currentId) main.post { finished() }
            }
        })
        val pending = ArrayList(queue)
        queue.clear()
        for (p in pending) speak(p.first, p.second)
    }

    fun isSpeaking(): Boolean = speaking

    fun speak(text: String, lang: Lang) {
        if (text.isBlank()) return
        if (!ready) {
            queue.add(Pair(text, lang))
            return
        }
        val engine = tts ?: return
        applyVoice(engine, text, lang)
        engine.setSpeechRate(settings.speechRate)
        requestFocus()
        currentId = "pratik_" + System.nanoTime()
        speaking = true
        onSpeakStart()
        val limit = minOf(3800, TextToSpeech.getMaxSpeechInputLength() - 1)
        val result = engine.speak(text.take(limit), TextToSpeech.QUEUE_FLUSH, null, currentId)
        if (result != TextToSpeech.SUCCESS) finished()
    }

    fun stop() {
        currentId = ""
        try {
            tts?.stop()
        } catch (e: Exception) {
            // engine already gone
        }
        finished()
    }

    private fun finished() {
        if (!speaking) return
        speaking = false
        currentId = ""
        abandonFocus()
        onSpeakDone()
    }

    private fun applyVoice(engine: TextToSpeech, text: String, lang: Lang) {
        val tags: List<String> = when {
            LanguageDetector.hasDevanagari(text) -> listOf("ne-NP", "hi-IN", "en-IN")
            lang == Lang.NE -> listOf("en-IN", "en-US")   // romanized Nepali reads best with an Indian-English voice
            else -> listOf("en-US", "en-IN", "en-GB")
        }
        for (tag in tags) {
            val loc = Locale.forLanguageTag(tag)
            if (engine.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) {
                engine.setLanguage(loc)
                return
            }
        }
    }

    private fun requestFocus() {
        if (focus == null) {
            focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .build()
        }
        focus?.let { audio.requestAudioFocus(it) }
    }

    private fun abandonFocus() {
        focus?.let { audio.abandonAudioFocusRequest(it) }
    }

    fun shutdown() {
        currentId = ""
        speaking = false
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // ignore
        }
        tts = null
        abandonFocus()
    }
}
