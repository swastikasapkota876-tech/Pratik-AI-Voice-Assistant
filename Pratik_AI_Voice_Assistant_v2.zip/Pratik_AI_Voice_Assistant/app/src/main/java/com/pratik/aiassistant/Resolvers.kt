package com.pratik.aiassistant

import android.content.Context
import android.content.Intent
import android.provider.ContactsContract

data class AppInfo(val label: String, val pkg: String)
data class ContactHit(val name: String, val number: String, val score: Int)

/** Finds an installed app from whatever the user said ("फेसबुक", "fb", "youtube"...). */
object AppResolver {
    private var cache: List<AppInfo> = emptyList()
    private var cacheTime = 0L

    @Suppress("DEPRECATION")
    @Synchronized
    fun installed(ctx: Context): List<AppInfo> {
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - cacheTime < 60_000) return cache
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
        cache = list
        cacheTime = now
        return list
    }

    fun find(ctx: Context, query: String): AppInfo? {
        val apps = installed(ctx)
        val q = Norm.normalize(query)
        if (q.isEmpty()) return null

        val candidates = ArrayList<String>()
        val direct = Lex.appAliases[q]
        if (direct != null) {
            candidates.addAll(direct.split("|"))
        } else {
            candidates.add(q)
            for (w in q.split(" ")) {
                val a = Lex.appAliases[w]
                if (a != null) candidates.addAll(a.split("|"))
            }
        }

        for (c in candidates) {
            val pkgs = Lex.appPackages[c] ?: continue
            for (p in pkgs) {
                val hit = apps.firstOrNull { it.pkg == p }
                if (hit != null) return hit
            }
        }

        var best: AppInfo? = null
        var bestScore = 0
        for (app in apps) {
            val label = Norm.normalize(app.label)
            if (label.isEmpty()) continue
            for (c in candidates) {
                val s = when {
                    label == c -> 100
                    label.startsWith(c) -> 80
                    label.contains(c) && c.length >= 3 -> 60
                    c.contains(label) && label.length >= 4 -> 50
                    label.length >= 5 && c.length >= 5 && Norm.near(label, c) -> 40
                    else -> 0
                }
                if (s > bestScore) {
                    bestScore = s
                    best = app
                }
            }
        }
        return best
    }
}

/** Finds contacts by name, alias ("aama" -> "Mummy"), or relation group, tolerant to emoji and small spelling drift. */
object ContactResolver {

    fun find(ctx: Context, settings: AppSettings, target: String): List<ContactHit> {
        val nt = Norm.normalize(target)
        if (nt.isEmpty()) return emptyList()

        val names = LinkedHashSet<String>()
        val alias = settings.aliases()[nt]
        if (alias != null) names.add(Norm.normalize(alias))
        if (names.isEmpty()) {
            val group = Lex.relationGroup(nt)
            if (group != null) {
                for (g in group) names.add(Norm.normalize(g))
            } else {
                names.add(nt)
            }
        }

        val hits = ArrayList<ContactHit>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val display = c.getString(0).orEmpty()
                val number = c.getString(1).orEmpty()
                if (display.isBlank() || number.isBlank()) continue
                val nd = Norm.normalize(display)
                var s = 0
                for (n in names) s = maxOf(s, score(nd, n))
                if (s >= 40) hits.add(ContactHit(display, number, s))
            }
        }

        val seen = HashSet<String>()
        return hits.sortedByDescending { it.score }.filter { h -> seen.add(h.number.filter { ch -> ch.isDigit() }) }
    }

    private fun score(name: String, cand: String): Int {
        if (name == cand) return 100
        val nt = name.split(" ")
        val ct = cand.split(" ")
        if (name.startsWith("$cand ")) return 85
        if (nt.contains(cand)) return 75
        if (ct.size > 1 && ct.all { it in nt }) return 70
        if (name.contains(cand) && cand.length >= 3) return 55
        if (cand.length >= 4 && nt.any { Norm.near(it, cand) }) return 45
        return 0
    }
}
