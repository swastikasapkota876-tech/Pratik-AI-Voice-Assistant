package com.pratik.aiassistant

enum class Verdict { ALLOW, CONFIRM, BLOCK }

/**
 * Permission layer between "something decided to do X" (parser or LLM) and Android.
 * Voice -> STT -> Parser/LLM -> SafetyGate -> PhoneController -> TTS
 */
object SafetyGate {
    private val blockWords = setOf(
        "delete", "erase", "wipe", "format", "uninstall", "factory", "reset",
        "\u0921\u093F\u0932\u093F\u091F", "\u0939\u091F\u093E\u0909", "\u092E\u0947\u091F", "\u0905\u0928\u0907\u0928\u094D\u0938\u094D\u091F\u0932"
    )
    private val confirmWords = setOf(
        "send", "pay", "buy", "purchase", "transfer", "order", "confirm", "install", "allow", "remove", "submit",
        "post", "checkout", "withdraw", "delete", "\u092A\u0920\u093E\u0909", "\u0924\u093F\u0930", "\u0915\u093F\u0928", "\u0905\u0928\u0941\u092E\u0924\u093F"
    )

    fun check(cmd: Command, settings: AppSettings, fromLlm: Boolean): Verdict = when (cmd) {
        is Command.Delete -> Verdict.BLOCK
        is Command.Sms -> Verdict.CONFIRM
        is Command.Call ->
            if (Lex.emergencyNumber(cmd.target) != null || settings.confirmCalls || fromLlm) Verdict.CONFIRM else Verdict.ALLOW
        is Command.ClickText -> {
            val w = Norm.words(cmd.text)
            when {
                w.any { it in blockWords } -> Verdict.BLOCK
                w.any { it in confirmWords } -> Verdict.CONFIRM
                else -> Verdict.ALLOW
            }
        }
        else -> Verdict.ALLOW
    }
}
