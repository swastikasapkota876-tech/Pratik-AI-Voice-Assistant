package com.pratik.aiassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Phone-control layer. Only acts when the brain asks (after the safety gate); it never watches or stores screen content.
 * Password fields are never typed into or read.
 */
class AssistantAccessibilityService : AccessibilityService() {

    enum class ClickResult { CLICKED, NOT_FOUND, NO_SCREEN }
    enum class TypeResult { TYPED, NO_FIELD, PASSWORD, NO_SCREEN }

    companion object {
        @Volatile
        var instance: AssistantAccessibilityService? = null
            private set

        @Volatile
        var lastPackage: String = ""
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (!pkg.isNullOrEmpty()) lastPackage = pkg
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------------------------------------------------

    fun global(kind: GlobalKind): Boolean = when (kind) {
        GlobalKind.HOME -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        GlobalKind.BACK -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        GlobalKind.RECENTS -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
        GlobalKind.NOTIFICATIONS -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        GlobalKind.QUICK_SETTINGS -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        GlobalKind.LOCK -> Build.VERSION.SDK_INT >= 28 && performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        GlobalKind.SCREENSHOT -> Build.VERSION.SDK_INT >= 28 && performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
    }

    // ------------------------------------------------------------------------------------------------------------
    // tree helpers

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (node == null || depth > 60 || out.size > 2500) return
        out.add(node)
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
    }

    private fun allNodes(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        collect(rootInActiveWindow, list, 0)
        return list
    }

    // ------------------------------------------------------------------------------------------------------------

    fun clickByText(query: String): ClickResult {
        val nodes = allNodes()
        if (nodes.isEmpty()) return ClickResult.NO_SCREEN
        val q = Norm.normalize(query)
        if (q.isEmpty()) return ClickResult.NOT_FOUND

        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        for (n in nodes) {
            if (!n.isVisibleToUser || n.isPassword) continue
            val labels = listOfNotNull(n.text?.toString(), n.contentDescription?.toString())
            for (s in labels) {
                val ns = Norm.normalize(s)
                val score = when {
                    ns == q -> 3
                    ns.startsWith(q) -> 2
                    ns.contains(q) -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    best = n
                }
            }
        }
        val target = best ?: return ClickResult.NOT_FOUND

        var cur: AccessibilityNodeInfo? = target
        var hops = 0
        while (cur != null && hops < 8) {
            if (cur.isClickable && cur.isEnabled) {
                return if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) ClickResult.CLICKED else ClickResult.NOT_FOUND
            }
            cur = cur.parent
            hops++
        }
        val r = Rect()
        target.getBoundsInScreen(r)
        return if (tap(r.centerX().toFloat(), r.centerY().toFloat())) ClickResult.CLICKED else ClickResult.NOT_FOUND
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun scroll(down: Boolean): Boolean {
        val scrollable = allNodes().firstOrNull { it.isScrollable && it.isVisibleToUser }
        if (scrollable != null) {
            val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (scrollable.performAction(action)) return true
        }
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val high = dm.heightPixels * 0.3f
        val low = dm.heightPixels * 0.7f
        val p = Path()
        if (down) {
            p.moveTo(x, low)
            p.lineTo(x, high)
        } else {
            p.moveTo(x, high)
            p.lineTo(x, low)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 300))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun typeText(text: String): TypeResult {
        val root = rootInActiveWindow ?: return TypeResult.NO_SCREEN
        var field: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (field == null || !field.isEditable) {
            field = allNodes().firstOrNull { it.isEditable && it.isVisibleToUser && !it.isPassword }
            if (field != null) field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        }
        if (field == null) return TypeResult.NO_FIELD
        if (field.isPassword) return TypeResult.PASSWORD

        val existing = if (field.isShowingHintText) "" else field.text?.toString().orEmpty()
        val merged = if (existing.isEmpty()) text else existing + " " + text
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, merged)
        return if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) TypeResult.TYPED else TypeResult.NO_FIELD
    }

    /** Visible, non-password text from the current window, de-duplicated. */
    fun readScreen(max: Int): String {
        val sb = StringBuilder()
        val seen = HashSet<String>()
        for (n in allNodes()) {
            if (!n.isVisibleToUser || n.isPassword) continue
            val s = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
            if (s.isEmpty() || !seen.add(s)) continue
            sb.append(s).append(". ")
            if (sb.length >= max) break
        }
        return sb.toString().take(max)
    }
}
