package com.pratik.aiassistant

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Small helpers for the programmatic dark UI. */
object Ui {
    val BG = 0xFF090909.toInt()
    val CARD = 0xFF161616.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFFAAAAAA.toInt()
    val ACCENT = 0xFF66FF99.toInt()
    val WARN = 0xFFFFB74D.toInt()
    val BLUE = 0xFF64B5F6.toInt()
    val BAD = 0xFFFF6E6E.toInt()
    val USER_BUBBLE = 0xFF1E3A5F.toInt()
    val BOT_BUBBLE = 0xFF222222.toInt()

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(color: Int, radiusPx: Float): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radiusPx
        return d
    }

    fun text(ctx: Context, s: String, sizeSp: Float, color: Int): TextView {
        val tv = TextView(ctx)
        tv.text = s
        tv.textSize = sizeSp
        tv.setTextColor(color)
        return tv
    }

    fun button(ctx: Context, label: String, onClick: () -> Unit): Button {
        val b = Button(ctx)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    fun card(ctx: Context): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.VERTICAL
        val p = dp(ctx, 14)
        l.setPadding(p, p, p, p)
        l.background = round(CARD, dp(ctx, 14).toFloat())
        val lp = matchWrap()
        lp.topMargin = dp(ctx, 12)
        l.layoutParams = lp
        return l
    }

    fun space(ctx: Context, heightDp: Int): View {
        val v = View(ctx)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(ctx, heightDp))
        return v
    }
}
