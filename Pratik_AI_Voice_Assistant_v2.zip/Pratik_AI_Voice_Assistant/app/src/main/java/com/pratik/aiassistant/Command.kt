package com.pratik.aiassistant

enum class GlobalKind { HOME, BACK, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK, SCREENSHOT }
enum class VolumeMode { UP, DOWN, MUTE, UNMUTE, MAX, SET, SHOW }
enum class PanelKind { WIFI, BLUETOOTH, LOCATION, AIRPLANE, HOTSPOT, DISPLAY, BATTERY_SAVER }

/** Everything the assistant knows how to do. The parser (or the LLM) produces these; nothing else touches the phone. */
sealed class Command {
    data class Call(val target: String) : Command()
    data class Sms(val target: String, val body: String) : Command()
    data class OpenApp(val name: String) : Command()
    data class WebSearch(val query: String) : Command()
    data class YouTube(val query: String) : Command()
    data class Navigate(val place: String) : Command()
    data class SetAlarm(val hour: Int, val minute: Int) : Command()
    data class SetTimer(val seconds: Int) : Command()
    data class Flashlight(val on: Boolean) : Command()
    data class Volume(val mode: VolumeMode, val percent: Int = -1) : Command()
    data class Global(val kind: GlobalKind) : Command()
    data class Panel(val kind: PanelKind) : Command()
    data class ClickText(val text: String) : Command()
    data class TypeText(val text: String) : Command()
    data class Scroll(val down: Boolean) : Command()
    data class SetLanguage(val mode: String) : Command()
    data class Delete(val important: Boolean) : Command()
    object ReadScreen : Command()
    object DescribeScreen : Command()
    object TellTime : Command()
    object TellDate : Command()
    object TellBattery : Command()
    object StopAssistant : Command()
    object CreatorQuestion : Command()
    object ImpersonationClaim : Command()
    object Greeting : Command()
    object Thanks : Command()
    object HowAreYou : Command()
    object WhoAreYou : Command()
    object Help : Command()
    object Unknown : Command()
}
