package com.pratik.aiassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged

class SettingsActivity : AppCompatActivity() {

    private class PermRow(val label: String, val ok: () -> Boolean, val fix: () -> Unit)

    private lateinit var settings: AppSettings
    private lateinit var permBox: LinearLayout
    private lateinit var aliasBox: LinearLayout
    private lateinit var baseEdit: EditText
    private lateinit var modelEdit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        renderPermissions()
        renderAliases()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        renderPermissions()
    }

    // ------------------------------------------------------------------------------------------------------------

    private fun buildUi(): View {
        val pad = Ui.dp(this, 16)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(pad, pad, pad, pad)

        content.addView(Ui.text(this, "Settings", 28f, Ui.TEXT))

        // ---- permissions ----
        header(content, "Permissions & phone control")
        permBox = LinearLayout(this)
        permBox.orientation = LinearLayout.VERTICAL
        content.addView(permBox, Ui.matchWrap())
        content.addView(Ui.button(this, "OPEN APP INFO") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, Ui.matchWrap())

        // ---- voice ----
        header(content, "Voice")
        content.addView(Ui.text(this, "Language", 14f, Ui.MUTED))
        radioRow(
            content,
            listOf("auto" to "Auto (Nepali + English)", "ne" to "Nepali", "en" to "English"),
            settings.languageMode
        ) { settings.languageMode = it }
        seekRow(content, "Speech speed", 60, 140, (settings.speechRate * 100).toInt(), { "$it%" }) { settings.speechRate = it / 100f }
        switchRow(content, "Offline speech recognition when available", settings.preferOffline) { settings.preferOffline = it }

        // ---- wake word ----
        header(content, "Wake word")
        switchRow(content, "Require wake word (recommended)", settings.wakeWordEnabled) { settings.wakeWordEnabled = it }
        content.addView(
            Ui.text(this, "Without it, every sentence the microphone hears is treated as a command.", 12f, Ui.MUTED)
        )
        editRow(content, "Wake word", settings.wakeWord, false) { settings.wakeWord = it.trim().ifEmpty { "pratik" } }
        seekRow(content, "Stay awake after replying", 4, 20, settings.followUpSeconds, { "$it s" }) { settings.followUpSeconds = it }

        // ---- safety ----
        header(content, "Safety")
        switchRow(content, "Always ask before calling", settings.confirmCalls) { settings.confirmCalls = it }
        content.addView(
            Ui.text(
                this,
                "Messages, emergency numbers and risky buttons are always confirmed. Files are never deleted by the assistant.",
                12f, Ui.MUTED
            )
        )

        // ---- AI brain ----
        header(content, "AI brain (optional)")
        content.addView(
            Ui.text(
                this,
                "When the built-in rules do not understand a sentence, it is sent to the AI provider you choose below. " +
                    "Your key is stored only on this phone. Endpoints must use https.",
                12f, Ui.MUTED
            )
        )
        switchRow(content, "Enable AI brain", settings.llmEnabled) { settings.llmEnabled = it }
        radioRow(
            content,
            listOf("openai" to "OpenAI-compatible (OpenAI, Groq, OpenRouter...)", "gemini" to "Google Gemini", "claude" to "Anthropic Claude"),
            settings.llmProvider
        ) { provider ->
            settings.llmProvider = provider
            baseEdit.setText(AppSettings.defaultBaseUrl(provider))
            modelEdit.setText(AppSettings.defaultModel(provider))
        }
        baseEdit = editRow(content, "Base URL", settings.llmBaseUrl, false) { settings.llmBaseUrl = it.trim() }
        modelEdit = editRow(content, "Model name", settings.llmModel, false) { settings.llmModel = it.trim() }
        editRow(content, "API key", settings.llmApiKey, true) { settings.llmApiKey = it.trim() }
        content.addView(Ui.button(this, "TEST AI CONNECTION") { testLlm() }, Ui.matchWrap())

        // ---- aliases ----
        header(content, "Contact nicknames")
        content.addView(
            Ui.text(
                this,
                "Teach the assistant names it cannot match, e.g. say \"aama\" -> contact \"Mummy\", or a Devanagari name -> the Latin contact name.",
                12f, Ui.MUTED
            )
        )
        aliasBox = LinearLayout(this)
        aliasBox.orientation = LinearLayout.VERTICAL
        content.addView(aliasBox, Ui.matchWrap())
        val spokenEdit = EditText(this)
        spokenEdit.hint = "What you say (e.g. aama)"
        spokenEdit.setHintTextColor(Ui.MUTED)
        spokenEdit.setTextColor(Ui.TEXT)
        val contactEdit = EditText(this)
        contactEdit.hint = "Contact name in your phone"
        contactEdit.setHintTextColor(Ui.MUTED)
        contactEdit.setTextColor(Ui.TEXT)
        content.addView(spokenEdit, Ui.matchWrap())
        content.addView(contactEdit, Ui.matchWrap())
        content.addView(Ui.button(this, "ADD NICKNAME") {
            val s = spokenEdit.text.toString().trim()
            val c = contactEdit.text.toString().trim()
            if (s.isEmpty() || c.isEmpty()) {
                Toast.makeText(this, "Fill both fields.", Toast.LENGTH_SHORT).show()
            } else {
                settings.setAlias(s, c)
                spokenEdit.setText("")
                contactEdit.setText("")
                renderAliases()
            }
        }, Ui.matchWrap())

        content.addView(Ui.space(this, 32))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.clipToPadding = false
        scroll.addView(content, Ui.matchWrap())
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        return scroll
    }

    // ---- small builders -----------------------------------------------------------------------------------------

    private fun header(parent: LinearLayout, title: String) {
        val tv = Ui.text(this, title, 18f, Ui.ACCENT)
        tv.setPadding(0, Ui.dp(this, 22), 0, Ui.dp(this, 6))
        parent.addView(tv)
    }

    private fun switchRow(parent: LinearLayout, label: String, initial: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SwitchCompat(this)
        sw.text = label
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        parent.addView(sw, Ui.matchWrap())
    }

    private fun editRow(parent: LinearLayout, hint: String, initial: String, secret: Boolean, onChange: (String) -> Unit): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(Ui.MUTED)
        e.setTextColor(Ui.TEXT)
        e.setText(initial)
        e.setSingleLine(true)
        if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.doAfterTextChanged { onChange(it?.toString().orEmpty()) }
        parent.addView(e, Ui.matchWrap())
        return e
    }

    private fun radioRow(parent: LinearLayout, options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit) {
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val ids = HashMap<Int, String>()
        for ((value, label) in options) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = label
            rb.setTextColor(Ui.TEXT)
            ids[rb.id] = value
            group.addView(rb)
            if (value == current) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val v = ids[checkedId]
            if (v != null) onPick(v)
        }
        parent.addView(group, Ui.matchWrap())
    }

    private fun seekRow(
        parent: LinearLayout, label: String, min: Int, max: Int, initial: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ) {
        val tv = Ui.text(this, label + ": " + fmt(initial), 14f, Ui.TEXT)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (initial - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + min
                tv.text = label + ": " + fmt(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb, Ui.matchWrap())
    }

    // ---- permissions --------------------------------------------------------------------------------------------

    private fun granted(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun request(p: String) {
        ActivityCompat.requestPermissions(this, arrayOf(p), 200)
    }

    private fun permRows(): List<PermRow> = listOf(
        PermRow("Microphone (required)", { granted(Manifest.permission.RECORD_AUDIO) }, { request(Manifest.permission.RECORD_AUDIO) }),
        PermRow("Contacts", { granted(Manifest.permission.READ_CONTACTS) }, { request(Manifest.permission.READ_CONTACTS) }),
        PermRow("Phone calls", { granted(Manifest.permission.CALL_PHONE) }, { request(Manifest.permission.CALL_PHONE) }),
        PermRow("Send SMS (optional)", { granted(Manifest.permission.SEND_SMS) }, { request(Manifest.permission.SEND_SMS) }),
        PermRow(
            "Notifications",
            { Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS) },
            { if (Build.VERSION.SDK_INT >= 33) request(Manifest.permission.POST_NOTIFICATIONS) }
        ),
        PermRow(
            "Phone control - Accessibility (tap, scroll, type, back/home)",
            { AssistantAccessibilityService.instance != null },
            { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        ),
        PermRow(
            "Display over other apps (reliable app launching)",
            { Settings.canDrawOverlays(this) },
            { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        ),
        PermRow(
            "Battery: don't optimize (keeps listening alive)",
            {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                pm.isIgnoringBatteryOptimizations(packageName)
            },
            { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        )
    )

    private fun renderPermissions() {
        permBox.removeAllViews()
        for (row in permRows()) {
            val ok = row.ok()
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = android.view.Gravity.CENTER_VERTICAL
            val label = Ui.text(this, (if (ok) "[OK]  " else "[ ! ]  ") + row.label, 14f, if (ok) Ui.ACCENT else Ui.WARN)
            line.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (!ok) line.addView(Ui.button(this, "Grant") { row.fix() })
            permBox.addView(line, Ui.matchWrap())
        }
    }

    // ---- aliases ------------------------------------------------------------------------------------------------

    private fun renderAliases() {
        aliasBox.removeAllViews()
        val all = settings.aliases()
        if (all.isEmpty()) {
            aliasBox.addView(Ui.text(this, "No nicknames yet.", 13f, Ui.MUTED))
            return
        }
        for ((key, contact) in all) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = android.view.Gravity.CENTER_VERTICAL
            val tv: TextView = Ui.text(this, "$key  ->  $contact", 14f, Ui.TEXT)
            line.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            line.addView(Ui.button(this, "Delete") {
                settings.removeAlias(key)
                renderAliases()
            })
            aliasBox.addView(line, Ui.matchWrap())
        }
    }

    // ---- AI test ------------------------------------------------------------------------------------------------

    private fun testLlm() {
        val s = AppSettings(this)
        Thread {
            val client = LlmClient(s)
            val msg = if (!client.isConfigured()) {
                "Turn on the AI brain, then fill in the model name and API key."
            } else {
                val r = client.chat(emptyList(), "Say hello in one short sentence.", LlmClient.Mode.PLAIN, Lang.EN)
                if (r.error != null) "Error: " + r.error else "OK: " + r.reply
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }
}
