package com.pratik.aiassistant

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/** All user settings. Stored privately (backup is disabled in the manifest so the API key never leaves the phone). */
class AppSettings(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("pratik_ai_settings", Context.MODE_PRIVATE)

    /** "auto" | "ne" | "en" */
    var languageMode: String
        get() = prefs.getString("lang_mode", "auto") ?: "auto"
        set(v) = prefs.edit().putString("lang_mode", v).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_enabled", true)
        set(v) = prefs.edit().putBoolean("wake_enabled", v).apply()

    var wakeWord: String
        get() = prefs.getString("wake_word", "pratik") ?: "pratik"
        set(v) = prefs.edit().putString("wake_word", v).apply()

    /** Seconds the assistant stays awake after speaking, so you can talk without repeating the wake word. */
    var followUpSeconds: Int
        get() = prefs.getInt("follow_up", 8)
        set(v) = prefs.edit().putInt("follow_up", v).apply()

    var speechRate: Float
        get() = prefs.getFloat("speech_rate", 0.94f)
        set(v) = prefs.edit().putFloat("speech_rate", v).apply()

    var preferOffline: Boolean
        get() = prefs.getBoolean("prefer_offline", false)
        set(v) = prefs.edit().putBoolean("prefer_offline", v).apply()

    var confirmCalls: Boolean
        get() = prefs.getBoolean("confirm_calls", false)
        set(v) = prefs.edit().putBoolean("confirm_calls", v).apply()

    // ---- AI brain (optional) ----
    var llmEnabled: Boolean
        get() = prefs.getBoolean("llm_enabled", false)
        set(v) = prefs.edit().putBoolean("llm_enabled", v).apply()

    /** "openai" (any OpenAI-compatible server) | "gemini" | "claude" */
    var llmProvider: String
        get() = prefs.getString("llm_provider", "openai") ?: "openai"
        set(v) = prefs.edit().putString("llm_provider", v).apply()

    var llmBaseUrl: String
        get() = prefs.getString("llm_base_url", defaultBaseUrl(llmProvider)) ?: defaultBaseUrl(llmProvider)
        set(v) = prefs.edit().putString("llm_base_url", v).apply()

    var llmModel: String
        get() = prefs.getString("llm_model", "") ?: ""
        set(v) = prefs.edit().putString("llm_model", v).apply()

    var llmApiKey: String
        get() = prefs.getString("llm_key", "") ?: ""
        set(v) = prefs.edit().putString("llm_key", v).apply()

    // ---- contact aliases: spoken name -> contact name ----
    fun aliases(): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val raw = prefs.getString("aliases", "{}") ?: "{}"
        try {
            val o = JSONObject(raw)
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                out[k] = o.optString(k)
            }
        } catch (e: Exception) {
            // corrupt data -> start clean
        }
        return out
    }

    fun setAlias(spoken: String, contactName: String) {
        val key = Norm.normalize(spoken)
        if (key.isEmpty() || contactName.isBlank()) return
        val o = JSONObject()
        for ((k, v) in aliases()) o.put(k, v)
        o.put(key, contactName.trim())
        prefs.edit().putString("aliases", o.toString()).apply()
    }

    fun removeAlias(key: String) {
        val o = JSONObject()
        for ((k, v) in aliases()) if (k != key) o.put(k, v)
        prefs.edit().putString("aliases", o.toString()).apply()
    }

    companion object {
        fun defaultBaseUrl(provider: String): String = when (provider) {
            "gemini" -> "https://generativelanguage.googleapis.com/v1beta"
            "claude" -> "https://api.anthropic.com/v1"
            else -> "https://api.openai.com/v1"
        }

        fun defaultModel(provider: String): String = when (provider) {
            "claude" -> "claude-haiku-4-5-20251001"
            else -> ""
        }
    }
}
