package com.pratik.aiassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat

/**
 * Continuous speech recognition that survives errors: one recognizer at a time, restart with back-off, pause while the
 * assistant is speaking (so it never hears itself), watchdog for recognizers that hang. Main thread only.
 */
class SpeechIn(
    private val ctx: Context,
    private val settings: AppSettings,
    private val cb: Callback
) {
    interface Callback {
        fun onResults(alternatives: List<String>)
        fun onFatal(message: String)
        fun onNotice(message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wanted = false
    private var paused = false
    private var running = false
    private var failures = 0
    private var forceEnglish = false

    private val restartTask = Runnable { startSession() }
    private val watchdogTask = Runnable {
        // recognizer went silent without any callback -> rebuild it
        running = false
        destroyRecognizer()
        scheduleRestart(500)
    }

    fun enable() {
        wanted = true
        paused = false
        scheduleRestart(200)
    }

    fun pause() {
        paused = true
        main.removeCallbacks(restartTask)
        main.removeCallbacks(watchdogTask)
        if (running) {
            try {
                recognizer?.cancel()
            } catch (e: Exception) {
                // ignore
            }
            running = false
        }
    }

    fun resume(delayMs: Long) {
        paused = false
        scheduleRestart(delayMs)
    }

    /** Apply changed settings (language etc.) immediately. */
    fun restartNow() {
        main.removeCallbacks(restartTask)
        main.removeCallbacks(watchdogTask)
        if (running) {
            try {
                recognizer?.cancel()
            } catch (e: Exception) {
                // ignore
            }
            running = false
        }
        forceEnglish = false
        scheduleRestart(150)
    }

    fun destroy() {
        wanted = false
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
    }

    // ------------------------------------------------------------------------------------------------------------

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartTask)
        if (wanted && !paused) main.postDelayed(restartTask, delayMs)
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        }
        recognizer = null
    }

    private fun startSession() {
        if (!wanted || paused || running) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            wanted = false
            cb.onFatal("Microphone permission chaina.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            wanted = false
            cb.onFatal("Sir, yo phone ma speech recognition available chaina.")
            return
        }
        val r: SpeechRecognizer = recognizer ?: SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        running = true
        main.removeCallbacks(watchdogTask)
        main.postDelayed(watchdogTask, 25_000)
        try {
            r.startListening(buildIntent())
        } catch (e: Exception) {
            running = false
            main.removeCallbacks(watchdogTask)
            destroyRecognizer()
            scheduleRestart(1500)
        }
    }

    private fun buildIntent(): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, settings.preferOffline)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        val mode = if (forceEnglish) "en" else settings.languageMode
        when (mode) {
            "en" -> i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            "ne" -> i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ne-NP")
            else -> {
                // auto: Nepali first, English as an additional hint (Android 13+ recognizers honour it)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ne-NP")
                i.putExtra(RecognizerIntent.EXTRA_ADDITIONAL_LANGUAGES, arrayOf("en-IN"))
            }
        }
        return i
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            failures = 0
            if (!paused) AssistantBus.setState(AssistantState.LISTENING)
        }

        override fun onBeginningOfSpeech() {
            main.removeCallbacks(watchdogTask)
            main.postDelayed(watchdogTask, 30_000)
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val first = list?.firstOrNull()
            if (!first.isNullOrBlank()) {
                AssistantBus.partial(first)
                main.removeCallbacks(watchdogTask)
                main.postDelayed(watchdogTask, 30_000)
            }
        }

        override fun onResults(results: Bundle?) {
            running = false
            main.removeCallbacks(watchdogTask)
            failures = 0
            AssistantBus.partial("")
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf<String>()
            if (list.isNotEmpty()) cb.onResults(list)
            scheduleRestart(250)
        }

        override fun onError(error: Int) {
            running = false
            main.removeCallbacks(watchdogTask)
            AssistantBus.partial("")
            when (error) {
                6, 7 -> scheduleRestart(200)                       // no speech / no match: normal while idle
                8 -> {                                              // recognizer busy
                    destroyRecognizer()
                    scheduleRestart(1000)
                }
                5 -> {                                              // client error
                    destroyRecognizer()
                    scheduleRestart(700)
                }
                9 -> {                                              // insufficient permissions
                    wanted = false
                    cb.onFatal("Microphone permission chaina.")
                }
                12, 13 -> {                                         // language not supported / unavailable
                    if (!forceEnglish && settings.languageMode != "en") {
                        forceEnglish = true
                        cb.onNotice("Nepali speech recognition available chaina, English use gardai chu.")
                        destroyRecognizer()
                        scheduleRestart(300)
                    } else {
                        backoff()
                    }
                }
                else -> backoff()
            }
        }
    }

    private fun backoff() {
        failures++
        destroyRecognizer()
        if (failures == 4) cb.onNotice("Sir, speech recognition ma problem cha (internet ya microphone check garnuhos).")
        val delay = minOf(8000L, 500L shl minOf(failures, 4))
        scheduleRestart(delay)
    }
}
