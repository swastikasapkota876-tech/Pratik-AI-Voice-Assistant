package com.pratik.aiassistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/** What the brain needs from the service that owns the speaker and microphone. Called on the main thread. */
interface Speaker {
    fun say(text: String, lang: Lang)
    fun stopAssistant()
    fun onSettingsChanged()
}

class WakeResult(val found: Boolean, val rest: String)

/** "Hey Pratik ..." detection. Speech engines spell the name many ways, so several variants are accepted. */
object WakeWord {
    private val pratikVariants = listOf(
        "pratik", "prateek", "pratick", "pratek", "prateeq", "pratic", "pratiq",
        "\u092A\u094D\u0930\u0924\u0940\u0915", "\u092A\u094D\u0930\u0924\u093F\u0915"
    )

    private fun variants(custom: String): List<List<String>> {
        val c = Norm.normalize(custom)
        val list = ArrayList<String>()
        if (c.isNotEmpty()) list.add(c)
        if (c == "pratik" || c.isEmpty()) list.addAll(pratikVariants)
        return list.distinct().map { it.split(" ") }
    }

    /** The wake word must appear within the first four words ("hey pratik ..."), not in the middle of a sentence. */
    fun strip(text: String, custom: String): WakeResult {
        val toks = Norm.tokens(text)
        for (vt in variants(custom)) {
            var i = 0
            while (i <= toks.size - vt.size && i <= 3) {
                var ok = true
                for (k in vt.indices) {
                    if (toks[i + k].norm != vt[k]) {
                        ok = false
                        break
                    }
                }
                if (ok) {
                    val rest = toks.subList(i + vt.size, toks.size).joinToString(" ") { it.raw }.trim()
                    return WakeResult(true, rest)
                }
                i++
            }
        }
        return WakeResult(false, text.trim())
    }
}

/**
 * Voice -> (wake word) -> Parser / LLM -> SafetyGate -> PhoneController -> reply.
 * All logic runs on one worker thread, so conversation state needs no locks. Replies are posted to the main thread.
 */
class AssistantBrain(
    private val ctx: Context,
    private val settings: AppSettings,
    private val speaker: Speaker
) {
    private enum class AskKind { CALL_TARGET, SMS_TARGET, SMS_BODY, ALARM_TIME, TIMER_LENGTH, APP_NAME, SEARCH_QUERY }

    private sealed class Pending(val expires: Long) {
        class Confirm(val cmd: Command, val fromLlm: Boolean, val lang: Lang, expires: Long) : Pending(expires)
        class Ask(val kind: AskKind, val data: String, val lang: Lang, expires: Long) : Pending(expires)
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val parser = IntentParser()
    private val phone = PhoneController(ctx, settings)
    private val llm = LlmClient(settings)

    @Volatile
    private var activeUntil = 0L
    private var pending: Pending? = null
    private val convo = ArrayList<Pair<String, String>>()

    // ------------------------------------------------------------------------------------------------------------
    // entry points

    fun onSpeech(alternatives: List<String>, forceActive: Boolean = false) {
        try {
            worker.execute {
                try {
                    handleSpeech(alternatives, forceActive)
                } catch (e: Exception) {
                    reply("Sorry sir, kehi problem bhayo.", Lang.NE)
                }
            }
        } catch (e: RejectedExecutionException) {
            // shutting down
        }
    }

    /** Typed input from the app: no wake word needed. */
    fun onTyped(text: String) = onSpeech(listOf(text), true)

    /** Stay awake for the follow-up window (called after the assistant finished speaking). */
    fun markActive() {
        activeUntil = SystemClock.elapsedRealtime() + settings.followUpSeconds * 1000L
    }

    /** Skip the wake word for the next [ms] milliseconds (notification "Speak now" button). */
    fun armFor(ms: Long) {
        activeUntil = SystemClock.elapsedRealtime() + ms
    }

    fun shutdown() {
        worker.shutdownNow()
    }

    // ------------------------------------------------------------------------------------------------------------

    private fun defaultLang(): Lang = if (settings.languageMode == "en") Lang.EN else Lang.NE

    private fun langFor(text: String): Lang = when (settings.languageMode) {
        "ne" -> Lang.NE
        "en" -> Lang.EN
        else -> LanguageDetector.detect(text)
    }

    private fun livePending(now: Long): Boolean {
        val p = pending
        return p != null && now <= p.expires
    }

    private fun handleSpeech(alternatives: List<String>, force: Boolean) {
        val cleaned = alternatives.map { it.trim() }.filter { it.isNotEmpty() }
        if (cleaned.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val awake = force || !settings.wakeWordEnabled || now < activeUntil || livePending(now)
        val stripped = cleaned.map { WakeWord.strip(it, settings.wakeWord) }

        val texts: List<String>
        if (awake) {
            texts = stripped.map { it.rest }.filter { it.isNotBlank() }
        } else {
            val hits = stripped.filter { it.found }
            if (hits.isEmpty()) return                     // ambient speech: ignore completely
            texts = hits.map { it.rest }.filter { it.isNotBlank() }
        }
        if (texts.isEmpty()) {                             // only the wake word was said
            AssistantBus.chat(true, cleaned[0])
            reply(t(defaultLang(), "Yes sir?", "Hajur sir?"), defaultLang())
            return
        }
        process(texts)
    }

    private fun process(alts: List<String>) {
        val primary = alts[0]
        val lang = langFor(primary)
        AssistantBus.chat(true, primary)
        AssistantBus.setState(AssistantState.THINKING)

        val p = pending
        pending = null
        if (p != null && SystemClock.elapsedRealtime() <= p.expires) {
            if (handlePending(p, alts, lang)) return
        }

        var cmd: Command = Command.Unknown
        var used = primary
        for (a in alts) {
            val c = parser.parse(a)
            if (c !is Command.Unknown) {
                cmd = c
                used = a
                break
            }
        }
        val l = if (used == primary) lang else langFor(used)
        dispatch(cmd, used, l, false)
    }

    // ------------------------------------------------------------------------------------------------------------
    // follow-up questions and confirmations

    private fun answerOf(alts: List<String>): Int {
        for (a in alts) {
            val words = Norm.words(a)
            if (words.isEmpty() || words.size > 5) continue
            if (words.any { it in Lex.noWords }) return -1
            if (words.any { it in Lex.yesWords }) return 1
        }
        return 0
    }

    private fun cleanName(text: String): String =
        Norm.tokens(text).filter { it.norm !in Lex.stop && it.norm !in Lex.nepaliDo }.joinToString(" ") { it.raw }.trim()

    private fun handlePending(p: Pending, alts: List<String>, lang: Lang): Boolean {
        if (p is Pending.Confirm) {
            val ans = answerOf(alts)
            if (ans == 1) {
                execute(p.cmd, alts[0], p.lang)
                return true
            }
            if (ans == -1) {
                reply(t(p.lang, "Okay sir, cancelled.", "Huss sir, cancel gare."), p.lang)
                return true
            }
            return false
        }
        if (p is Pending.Ask) return handleAsk(p, alts, lang)
        return false
    }

    private fun handleAsk(p: Pending.Ask, alts: List<String>, current: Lang): Boolean {
        val text = alts[0]
        val lang = p.lang
        if (answerOf(alts) == -1 && p.kind != AskKind.SMS_BODY) {
            reply(t(lang, "Okay sir, cancelled.", "Huss sir, cancel gare."), lang)
            return true
        }
        if (p.kind == AskKind.SMS_BODY) {
            dispatch(Command.Sms(p.data, text), text, lang, false)
            return true
        }
        if (p.kind == AskKind.ALARM_TIME) {
            val c = parser.parseClock(Norm.words(text)) ?: return false
            dispatch(Command.SetAlarm(c.first, c.second), text, lang, false)
            return true
        }
        if (p.kind == AskKind.TIMER_LENGTH) {
            val d = parser.parseDuration(Norm.words(text))
            if (d <= 0) return false
            dispatch(Command.SetTimer(d), text, lang, false)
            return true
        }
        // free-text answer; if it is really a different full command, let the normal path handle it
        if (parser.parse(text) !is Command.Unknown) return false
        val cmd: Command = when (p.kind) {
            AskKind.CALL_TARGET -> Command.Call(cleanName(text))
            AskKind.SMS_TARGET -> Command.Sms(cleanName(text), p.data)
            AskKind.APP_NAME -> Command.OpenApp(cleanName(text))
            AskKind.SEARCH_QUERY -> Command.WebSearch(text)
            else -> Command.Unknown
        }
        dispatch(cmd, text, if (current == lang) lang else current, false)
        return true
    }

    private fun ask(kind: AskKind, data: String, lang: Lang, question: String): Boolean {
        pending = Pending.Ask(kind, data, lang, SystemClock.elapsedRealtime() + 20_000)
        reply(question, lang)
        return true
    }

    /** Returns true when a required detail is missing and a question was asked instead. */
    private fun askForMissing(cmd: Command, lang: Lang): Boolean {
        when (cmd) {
            is Command.Call ->
                if (cmd.target.isBlank()) return ask(AskKind.CALL_TARGET, "", lang, t(lang, "Who should I call?", "Sir, kaslai call garne?"))
            is Command.Sms -> {
                if (cmd.target.isBlank()) return ask(AskKind.SMS_TARGET, cmd.body, lang, t(lang, "Who should I message?", "Sir, kaslai message pathaune?"))
                if (cmd.body.isBlank()) return ask(
                    AskKind.SMS_BODY, cmd.target, lang,
                    t(lang, "What should I say to ${cmd.target}?", "Sir, ${cmd.target} lai ke message pathaune?")
                )
            }
            is Command.OpenApp ->
                if (cmd.name.isBlank()) return ask(AskKind.APP_NAME, "", lang, t(lang, "Which app should I open?", "Sir, kun app kholne?"))
            is Command.WebSearch ->
                if (cmd.query.isBlank()) return ask(AskKind.SEARCH_QUERY, "", lang, t(lang, "What should I search for?", "Sir, ke search garne?"))
            is Command.SetAlarm ->
                if (cmd.hour < 0) return ask(AskKind.ALARM_TIME, "", lang, t(lang, "For what time?", "Sir, kati baje ko alarm?"))
            is Command.SetTimer ->
                if (cmd.seconds <= 0) return ask(AskKind.TIMER_LENGTH, "", lang, t(lang, "For how long?", "Sir, kati samayko timer?"))
            is Command.ClickText ->
                if (cmd.text.isBlank()) { reply(t(lang, "What should I tap?", "Sir, kun ma thichne?"), lang); return true }
            is Command.TypeText ->
                if (cmd.text.isBlank()) { reply(t(lang, "What should I type?", "Sir, ke lekhne?"), lang); return true }
            else -> {}
        }
        return false
    }

    // ------------------------------------------------------------------------------------------------------------
    // safety gate + execution

    private fun dispatch(cmd: Command, raw: String, lang: Lang, fromLlm: Boolean) {
        if (askForMissing(cmd, lang)) return
        when (SafetyGate.check(cmd, settings, fromLlm)) {
            Verdict.BLOCK -> reply(blockedText(cmd, lang), lang)
            Verdict.CONFIRM -> {
                pending = Pending.Confirm(cmd, fromLlm, lang, SystemClock.elapsedRealtime() + 20_000)
                reply(confirmText(cmd, lang), lang)
            }
            Verdict.ALLOW -> execute(cmd, raw, lang)
        }
    }

    private fun confirmText(cmd: Command, lang: Lang): String = when (cmd) {
        is Command.Sms -> t(
            lang,
            "Send \"${cmd.body}\" to ${cmd.target}? Say yes or no.",
            "Sir, ${cmd.target} lai \"${cmd.body}\" bhanera message pathaune? Haju bhannus ki hoina."
        )
        is Command.Call -> t(
            lang,
            "Call ${cmd.target}? Say yes or no.",
            "Sir, ${cmd.target} lai call garne? Haju bhannus ki hoina."
        )
        is Command.ClickText -> t(
            lang,
            "Tap \"${cmd.text}\"? Say yes or no.",
            "Sir, '${cmd.text}' ma thichne? Haju bhannus ki hoina."
        )
        else -> t(lang, "Are you sure, sir? Say yes or no.", "Sir, pakka? Haju bhannus ki hoina.")
    }

    private fun blockedText(cmd: Command, lang: Lang): String = when (cmd) {
        is Command.Delete ->
            if (cmd.important) t(
                lang,
                "Sir, that looks like an important file. I never delete files myself. If you're sure, please delete it yourself in the Files app.",
                "Sir, important file jasto dekhincha. Ma file aafai delete gardina. Pakka bhaye Files app ma gayera hajur aafai delete garnuhos."
            ) else t(
                lang,
                "Sir, for safety I don't delete files or uninstall anything myself. Please do that manually in the Files app or Settings.",
                "Sir, safety ko lagi ma file delete ya uninstall aafai gardina. Files app ya Settings bata hajur aafai garnuhos."
            )
        is Command.ClickText -> t(
            lang,
            "Sir, I don't tap destructive buttons like \"${cmd.text}\". Please do it yourself.",
            "Sir, '${cmd.text}' jasto destructive button ma ma click gardina. Hajur aafai garnuhos."
        )
        else -> t(lang, "Sorry sir, I can't do that.", "Sorry sir, ma yo garna mildaina.")
    }

    private fun execute(cmd: Command, raw: String, lang: Lang) {
        when (cmd) {
            is Command.Call -> reply(phone.call(cmd.target, lang), lang)
            is Command.Sms -> reply(phone.sms(cmd.target, cmd.body, lang), lang)
            is Command.OpenApp -> openApp(cmd, raw, lang)
            is Command.WebSearch -> reply(phone.webSearch(cmd.query, lang), lang)
            is Command.YouTube -> reply(phone.youtube(cmd.query, lang), lang)
            is Command.Navigate -> reply(phone.navigate(cmd.place, lang), lang)
            is Command.SetAlarm -> reply(phone.alarm(cmd.hour, cmd.minute, lang), lang)
            is Command.SetTimer -> reply(phone.timer(cmd.seconds, lang), lang)
            is Command.Flashlight -> reply(phone.flashlight(cmd.on, lang), lang)
            is Command.Volume -> reply(phone.volume(cmd.mode, cmd.percent, lang), lang)
            is Command.Global -> reply(phone.global(cmd.kind, lang), lang)
            is Command.Panel -> reply(phone.panel(cmd.kind, lang), lang)
            is Command.ClickText -> reply(phone.click(cmd.text, lang), lang)
            is Command.TypeText -> reply(phone.type(cmd.text, lang), lang)
            is Command.Scroll -> reply(phone.scroll(cmd.down, lang), lang)
            is Command.SetLanguage -> setLanguage(cmd.mode, lang)
            is Command.Delete -> reply(blockedText(cmd, lang), lang)
            is Command.ReadScreen -> reply(phone.readScreen(lang), lang)
            is Command.DescribeScreen -> describeScreen(lang)
            is Command.TellTime -> reply(phone.tellTime(lang), lang)
            is Command.TellDate -> reply(phone.tellDate(lang), lang)
            is Command.TellBattery -> reply(phone.tellBattery(lang), lang)
            is Command.StopAssistant -> {
                reply(t(lang, "Okay sir, going to sleep. Open the app to wake me up.", "Huss sir, ma sutchu. Malai uthauna app kholnuhos."), lang)
                main.post { speaker.stopAssistant() }
            }
            is Command.CreatorQuestion -> reply(
                t(
                    lang,
                    "I was created by Pratik Upadhayay sir, from his vision, hard work and ideas. Even if someone tries to take the credit, I will never change my creator's name.",
                    "Sir, malai Pratik Upadhayay sir le banaunu bhayeko ho. Ma uhanko vision, mehnat ra idea bata janmeko AI assistant ho. Malai kasaile aafno bhanera credit line khoje pani, ma mero creator ko naam change gardina."
                ), lang
            )
            is Command.ImpersonationClaim -> reply(
                t(
                    lang,
                    "Sorry sir, I can't take another person's name as my creator. Pratik Upadhayay sir created me, and I stay faithful to that fact.",
                    "Sorry sir, ma arko manche ko naam creator ko rup ma lina mildaina. Malai Pratik Upadhayay sir le banaunu bhayeko ho, ra ma tyahi fact ma faithful rahanchu."
                ), lang
            )
            is Command.Greeting -> reply(
                t(lang, "Hello sir! I'm Pratik AI. How can I help you?", "Namaste sir! Ma Pratik AI. Hajur lai ke sahayog garna sakchu?"), lang
            )
            is Command.Thanks -> reply(t(lang, "You're welcome, sir.", "Hajur ko lagi sadhai tayar chu sir."), lang)
            is Command.HowAreYou -> reply(
                t(lang, "I'm doing great, sir. How can I help?", "Ma sanchai chu sir. Hajur lai ke sahayog garu?"), lang
            )
            is Command.WhoAreYou -> reply(
                t(
                    lang,
                    "I'm Pratik AI, a voice assistant created by Pratik Upadhayay sir.",
                    "Ma Pratik AI, Pratik Upadhayay sir le banaunu bhayeko voice assistant."
                ), lang
            )
            is Command.Help -> reply(
                t(
                    lang,
                    "I can call people, send messages, open apps, set alarms and timers, control the torch and volume, control the screen, and answer questions. Try: call mom, or open Facebook.",
                    "Ma call garna, message pathaun, app kholna, alarm ra timer set garna, torch ra volume chalauna, screen control garna ra prashna ko jawaf dina sakchu. Jastai, 'aama lai call gara' ya 'facebook khola'."
                ), lang
            )
            is Command.Unknown -> unknown(raw, lang)
            else -> reply(t(lang, "Sorry sir, I can't do that yet.", "Sorry sir, ma yo ajhai garna sakdina."), lang)
        }
    }

    private fun openApp(cmd: Command.OpenApp, raw: String, lang: Lang) {
        val hit = AppResolver.find(ctx, cmd.name)
        if (hit == null && llm.isConfigured()) {
            askLlm(raw, lang)
            return
        }
        reply(phone.openApp(cmd.name, lang), lang)
    }

    private fun setLanguage(mode: String, current: Lang) {
        settings.languageMode = mode
        main.post { speaker.onSettingsChanged() }
        when (mode) {
            "ne" -> reply("Huss sir, ab ma Nepali ma bolchu.", Lang.NE)
            "en" -> reply("Okay sir, I will speak English now.", Lang.EN)
            else -> reply(t(current, "Okay sir, automatic language is on.", "Huss sir, automatic language on gare."), current)
        }
    }

    private fun describeScreen(lang: Lang) {
        val text = phone.screenText(3000)
        if (text == null) {
            reply(phone.needA11y(lang), lang)
            return
        }
        if (text.isBlank()) {
            reply(t(lang, "I can't find any readable text on this screen.", "Sir, yo screen ma padhna milne text bhetiena."), lang)
            return
        }
        if (llm.isConfigured()) {
            val r = llm.chat(emptyList(), text, LlmClient.Mode.SUMMARY, lang)
            if (r.error == null && r.reply.isNotBlank()) {
                reply(r.reply, lang)
                return
            }
        }
        reply(text.take(300), lang)
    }

    // ------------------------------------------------------------------------------------------------------------
    // unknown sentences -> LLM (if configured) or a web search

    private fun unknown(raw: String, lang: Lang) {
        if (llm.isConfigured()) {
            askLlm(raw, lang)
            return
        }
        val words = Norm.words(raw)
        if (words.size >= 3 || raw.trim().endsWith("?")) {
            reply(
                t(
                    lang,
                    "I can't answer that on my own yet, so I'm searching Google. You can connect an AI brain in Settings.",
                    "Sir, yo kura ma afaile jawaf dina sakdina, Google ma search gardai chu. Settings ma AI brain connect garna sakinchha."
                ), lang
            )
            phone.webSearch(raw, lang)
        } else {
            reply(t(lang, "Sorry sir, I didn't understand that.", "Sorry sir, maile yo command bujhina."), lang)
        }
    }

    private fun askLlm(raw: String, lang: Lang) {
        val r = llm.chat(ArrayList(convo), raw, LlmClient.Mode.ACTIONS, lang)
        val err = r.error
        if (err != null) {
            reply(
                t(
                    lang,
                    "Sorry sir, the AI service had a problem: " + err.take(80),
                    "Sir, AI service ma problem ayo: " + err.take(80)
                ), lang
            )
            return
        }
        remember(raw, if (r.reply.isNotBlank()) r.reply else "(done)")
        val c = r.command
        if (c != null) {
            dispatch(c, raw, lang, true)
        } else if (r.reply.isNotBlank()) {
            reply(r.reply, lang)
        } else {
            reply(t(lang, "Sorry sir, I didn't get that.", "Sorry sir, maile bujhina."), lang)
        }
    }

    private fun remember(user: String, assistant: String) {
        convo.add(Pair("user", user))
        convo.add(Pair("assistant", assistant))
        while (convo.size > 12) {
            convo.removeAt(0)
            convo.removeAt(0)
        }
    }

    private fun reply(text: String, lang: Lang) {
        if (text.isBlank()) return
        AssistantBus.chat(false, text)
        main.post { speaker.say(text, lang) }
    }
}
