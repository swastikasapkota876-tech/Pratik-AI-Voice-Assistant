package com.pratik.aiassistant

import java.util.Calendar

/** Wraps one utterance: tokens, normalized words and a padded string for whole-word phrase matching. */
private class Q(val toks: List<Tok>) {
    val words: List<String> = toks.map { it.norm }
    val t: String = " " + words.joinToString(" ") + " "
    fun has(vararg p: String): Boolean = p.any { t.contains(" $it ") }
    fun anyWord(vararg w: String): Boolean = words.any { it in w }
    fun anyIn(s: Set<String>): Boolean = words.any { it in s }
    fun raw(list: List<Tok>): String = list.joinToString(" ") { it.raw }.trim()
}

/**
 * Rule based, multilingual (English / romanized Nepali / Devanagari) intent parser.
 * Pure function of the text, so it is easy to unit-test. Anything it cannot understand becomes [Command.Unknown]
 * and is handed to the optional LLM planner.
 */
class IntentParser {

    fun parse(raw: String): Command {
        val toks = Norm.tokens(raw)
        if (toks.isEmpty()) return Command.Unknown
        val q = Q(toks)

        // ---- persona ----
        if (isCreatorQuestion(q.t)) return Command.CreatorQuestion
        if (Lex.impersonation.any { q.t.contains(it) }) return Command.ImpersonationClaim

        // ---- assistant control ----
        parseLanguage(q)?.let { return it }
        if (q.has("stop listening", "stop assistant", "assistant off", "go to sleep", "sleep mode", "sunna band", "sunne band",
                "\u0938\u0941\u0928\u094D\u0928 \u092C\u0928\u094D\u0926", "\u0938\u0941\u0928\u094D\u0928 \u091B\u094B\u0921")) {
            return Command.StopAssistant
        }

        // ---- destructive requests are recognised first so "delete facebook" never opens Facebook ----
        if (q.anyIn(Lex.deleteWords) || q.has("remove file", "remove files", "remove photo", "remove photos", "clear all data", "reset phone")) {
            return Command.Delete(q.anyIn(Lex.importantWords))
        }

        // ---- system buttons expressed with several words ----
        if (q.anyWord("screenshot", "\u0938\u094D\u0915\u094D\u0930\u093F\u0928\u0938\u091F", "\u0938\u094D\u0915\u094D\u0930\u0940\u0928\u0936\u091F", "\u0938\u094D\u0915\u094D\u0930\u093F\u0928\u0936\u091F", "\u0938\u094D\u0915\u094D\u0930\u0940\u0928\u0938\u091F") ||
            q.has("screen shot")) return Command.Global(GlobalKind.SCREENSHOT)
        if (q.has("lock screen", "screen lock", "lock phone", "phone lock", "lock the phone", "lock my phone", "lock garnu",
                "\u092B\u094B\u0928 \u0932\u0915", "\u0938\u094D\u0915\u094D\u0930\u093F\u0928 \u0932\u0915")) return Command.Global(GlobalKind.LOCK)
        if (q.has("quick settings", "quick setting", "control center", "\u0915\u094D\u0935\u093F\u0915 \u0938\u0947\u091F\u093F\u0919")) return Command.Global(GlobalKind.QUICK_SETTINGS)
        if (q.anyWord("notification", "notifications", "\u0928\u094B\u091F\u093F\u092B\u093F\u0915\u0947\u0938\u0928", "\u0928\u094B\u091F\u093F\u092B\u093F\u0915\u0947\u0936\u0928")) return Command.Global(GlobalKind.NOTIFICATIONS)
        if (q.anyWord("recents", "recent", "overview", "\u0930\u093F\u0938\u0947\u0928\u094D\u091F") || q.has("app switcher")) return Command.Global(GlobalKind.RECENTS)

        // ---- screen reading ----
        val screenWord = q.anyWord("screen", "\u0938\u094D\u0915\u094D\u0930\u093F\u0928", "\u0938\u094D\u0915\u094D\u0930\u0940\u0928")
        if (screenWord) {
            if (q.anyWord("describe", "summarize", "summarise", "explain", "summary", "bujhau", "bujhaideu", "\u092C\u0941\u091D\u093E\u0909", "\u0938\u093E\u0930\u093E\u0902\u0936")) return Command.DescribeScreen
            if (q.anyWord("read", "padha", "padhi", "padhnu", "\u092A\u0922", "\u092A\u0922\u094D\u0928\u0941")) return Command.ReadScreen
            if (q.anyWord("what", "what's", "whats", "ke", "k", "\u0915\u0947") && q.anyWord("on", "ma", "\u092E\u093E", "cha", "chha", "\u091B")) return Command.DescribeScreen
        }

        // ---- UI control (accessibility) ----
        if (q.anyWord("scroll", "swipe", "\u0938\u094D\u0915\u094D\u0930\u094B\u0932")) {
            val up = q.anyWord("up", "mathi", "\u092E\u093E\u0925\u093F", "upar")
            return Command.Scroll(!up)
        }
        if (q.anyIn(Lex.clickVerbs)) return parseClick(q)

        // ---- messages before calls ("message to mom" must not become a call) ----
        val smsish = (q.anyIn(Lex.smsNouns) && q.anyIn(Lex.sendVerbs)) ||
            q.has("message to", "msg to", "sms to", "text to") ||
            (q.words[0] == "text" && q.size() > 1)
        if (smsish) return parseSms(q)

        // ---- typing ----
        if (q.anyIn(Lex.typeVerbsEn) || q.anyIn(Lex.typeVerbsNe)) parseType(q)?.let { return it }

        // ---- calls ----
        val callish = q.anyIn(Lex.callVerbs) ||
            (q.anyIn(Lex.weakCallVerbs) && (q.anyIn(Lex.nepaliDo) || q.anyIn(Lex.lagau))) ||
            q.has("talk to", "speak to", "speak with", "talk with", "sanga kura", "\u0938\u0901\u0917 \u0915\u0941\u0930\u093E", "\u0938\u0919\u094D\u0917 \u0915\u0941\u0930\u093E")
        if (callish) return parseCall(q)

        // ---- alarm / timer ----
        val alarmWord = q.anyWord("alarm", "\u0905\u0932\u093E\u0930\u094D\u092E", "jagau", "jagaideu", "jagaidinu", "\u091C\u0917\u093E\u0909", "\u091C\u0917\u093E\u0907\u0926\u0947\u0909") || q.has("wake me", "wake me up")
        val timerWord = q.anyWord("timer", "\u091F\u093E\u0907\u092E\u0930", "countdown", "remind", "reminder")
        if (timerWord || alarmWord) {
            val dur = parseDuration(q.words)
            if (timerWord) return Command.SetTimer(dur)
            if (dur > 0 && q.anyWord("in", "after", "pachi", "\u092A\u091B\u093F", "\u092A\u091B\u0940")) return Command.SetTimer(dur)
            val c = parseClock(q.words)
            return if (c != null) Command.SetAlarm(c.first, c.second) else Command.SetAlarm(-1, 0)
        }

        // ---- flashlight ----
        if (q.anyIn(Lex.flashWords)) return Command.Flashlight(!q.anyIn(Lex.offWords))

        // ---- volume ----
        val volWord = q.anyWord("volume", "\u092D\u094B\u0932\u094D\u092F\u0941\u092E", "\u092D\u094B\u0932\u094D\u092F\u0942\u092E", "awaj", "awaz", "\u0906\u0935\u093E\u091C")
        if (q.anyWord("unmute")) return Command.Volume(VolumeMode.UNMUTE)
        if (q.anyWord("mute", "silent", "chup", "\u091A\u0941\u092A")) return Command.Volume(VolumeMode.MUTE)
        if (volWord) {
            val pct = q.words.firstNotNullOfOrNull { w -> w.removeSuffix("%").toIntOrNull()?.takeIf { it in 0..100 } }
            if (pct != null) return Command.Volume(VolumeMode.SET, pct)
            if (q.anyIn(Lex.maxWords)) return Command.Volume(VolumeMode.MAX)
            if (q.anyIn(Lex.upWords)) return Command.Volume(VolumeMode.UP)
            if (q.anyIn(Lex.downWords)) return Command.Volume(VolumeMode.DOWN)
            return Command.Volume(VolumeMode.SHOW)
        }

        // ---- settings panels ----
        val panel = panelFor(q)
        if (panel != null && (q.anyIn(Lex.openVerbs) || q.anyIn(Lex.nepaliDo) || q.anyIn(Lex.onOff) ||
                q.anyWord("settings", "setting", "turn", "switch", "\u0938\u0947\u091F\u093F\u0919"))) {
            return Command.Panel(panel)
        }

        // ---- information ----
        if (q.has("what time", "time kati", "kati bajyo", "kati baje", "current time", "the time", "samaya kati",
                "\u0938\u092E\u092F \u0915\u0924\u093F", "\u0915\u0924\u093F \u092C\u091C\u094D\u092F\u094B", "\u0915\u0924\u093F \u092C\u091C\u0947", "ahile kati bajyo", "time bata") ||
            (q.size() <= 3 && q.anyWord("time", "\u0938\u092E\u092F", "samaya"))) return Command.TellTime
        if (q.has("what date", "today date", "date today", "aaja ko date", "aajako date", "aaja k gate", "what day",
                "aaja kun bar", "date kati", "what is the date", "\u0906\u091C\u0915\u094B \u092E\u093F\u0924\u093F", "\u0906\u091C \u0915\u0941\u0928 \u0917\u0924\u0947", "\u0906\u091C \u0915\u0941\u0928 \u092C\u093E\u0930") ||
            (q.size() <= 3 && q.anyWord("date", "\u092E\u093F\u0924\u093F", "\u0917\u0924\u0947", "gate"))) return Command.TellDate
        if (q.anyWord("battery", "\u092C\u094D\u092F\u093E\u091F\u094D\u0930\u0940", "\u092C\u094D\u092F\u093E\u091F\u0930\u0940", "battary") || q.has("charge kati")) return Command.TellBattery

        // ---- navigation / media / web ----
        if (q.anyIn(Lex.navWords) || q.has("take me to", "how to get to")) {
            val place = q.raw(q.toks.filter { it.norm !in Lex.navNoise })
            return Command.Navigate(place)
        }
        if (q.anyIn(Lex.youtubeWords)) {
            val drop = Lex.youtubeWords + Lex.playVerbs + Lex.openVerbs + Lex.searchVerbs + Lex.nepaliDo +
                setOf("on", "in", "ma", "\u092E\u093E", "the", "a", "please", "hey", "ok", "okay", "lai", "\u0932\u093E\u0908", "app")
            return Command.YouTube(q.raw(q.toks.filter { it.norm !in drop }))
        }
        if (q.anyIn(Lex.playVerbs)) {
            val drop = Lex.playVerbs + Lex.nepaliDo + setOf("please", "hey", "ok", "okay", "lai", "\u0932\u093E\u0908", "on", "ma")
            val query = q.raw(q.toks.filter { it.norm !in drop })
            if (query.isNotBlank()) return Command.YouTube(query)
        }
        if (q.anyIn(Lex.searchVerbs)) {
            return Command.WebSearch(q.raw(q.toks.filter { it.norm !in Lex.searchNoise }))
        }

        // ---- apps ----
        if (q.anyIn(Lex.openVerbs)) {
            val drop = Lex.openVerbs + Lex.stop + Lex.nepaliDo
            return Command.OpenApp(q.raw(q.toks.filter { it.norm !in drop }))
        }
        if (q.size() <= 3 && q.anyIn(Lex.knownAppWords)) {
            return Command.OpenApp(q.raw(q.toks.filter { it.norm !in Lex.stop }))
        }

        // ---- simple system buttons ----
        if (q.size() <= 5) {
            if (q.anyWord("home", "\u0939\u094B\u092E") || q.has("home screen", "go home")) return Command.Global(GlobalKind.HOME)
            if (q.anyWord("back", "pachadi", "pachhadi", "\u092A\u091B\u093E\u0921\u093F", "\u092A\u091B\u093E\u0921\u0940")) return Command.Global(GlobalKind.BACK)
        }

        // ---- small talk ----
        if (q.has("thank you", "thanks", "thankyou", "dhanyabad", "\u0927\u0928\u094D\u092F\u0935\u093E\u0926")) return Command.Thanks
        if (q.has("how are you", "kasto cha", "kasto chha", "sanchai chau", "\u0915\u0938\u094D\u0924\u094B \u091B", "\u0938\u0928\u094D\u091A\u0948 \u091B\u094C") ||
            (q.size() <= 3 && q.has("k cha", "\u0915\u0947 \u091B"))) return Command.HowAreYou
        if (q.has("who are you", "what is your name", "your name", "timi ko ho", "timro naam", "tapai ko hunuhuncha",
                "\u0924\u093F\u092E\u0940 \u0915\u094B \u0939\u094C", "\u0924\u093F\u092E\u094D\u0930\u094B \u0928\u093E\u092E", "\u0924\u092A\u093E\u0908\u0902 \u0915\u094B \u0939\u0941\u0928\u0941\u0939\u0941\u0928\u094D\u091B")) return Command.WhoAreYou
        if (q.has("what can you do", "k k garna sakchau", "\u0915\u0947 \u0915\u0947 \u0917\u0930\u094D\u0928 \u0938\u0915\u094D\u091B\u094C") ||
            (q.size() <= 4 && q.anyWord("help", "madat", "sahayog", "\u092E\u0926\u094D\u0926\u0924", "\u0938\u0939\u092F\u094B\u0917"))) return Command.Help
        if (q.size() <= 3 && q.anyWord("hello", "hi", "hey", "helo", "namaste", "namaskar", "hola",
                "\u0928\u092E\u0938\u094D\u0924\u0947", "\u0928\u092E\u0938\u094D\u0915\u093E\u0930", "\u0939\u0947\u0932\u094B")) return Command.Greeting

        return Command.Unknown
    }

    // ------------------------------------------------------------------------------------------------------------

    private fun isCreatorQuestion(t: String): Boolean {
        val direct = listOf(
            " your creator ", " your maker ", " your owner ", " your developer ", " timro creator ", " timro malik ",
            " timro nirmata ", " \u0924\u093F\u092E\u094D\u0930\u094B \u0928\u093F\u0930\u094D\u092E\u093E\u0924\u093E ", " \u0924\u093F\u092E\u094D\u0930\u094B \u092E\u093E\u0932\u093F\u0915 "
        )
        if (direct.any { t.contains(it) }) return true
        val verbs = listOf(
            " who created ", " who made ", " who built ", " who developed ", " who designed ", " kasle banayo ",
            " kasle banaunu ", " kasle banayeko ", " kasle banaeko ", " kasle banaye ",
            " \u0924\u093F\u092E\u0940\u0932\u093E\u0908 \u0915\u0938\u0932\u0947 ", " \u0924\u092A\u093E\u0908\u0902\u0932\u093E\u0908 \u0915\u0938\u0932\u0947 ",
            " \u0915\u0938\u0932\u0947 \u092C\u0928\u093E\u092F\u094B ", " \u0915\u0938\u0932\u0947 \u092C\u0928\u093E\u090F\u0915\u094B "
        )
        val subj = listOf(
            " you ", " u ", " timilai ", " tapailai ", " timi ", " \u0924\u093F\u092E\u0940 ", " \u0924\u093F\u092E\u0940\u0932\u093E\u0908 ",
            " \u0924\u092A\u093E\u0908\u0902 ", " \u0924\u092A\u093E\u0908\u0902\u0932\u093E\u0908 "
        )
        return verbs.any { t.contains(it) } && subj.any { t.contains(it) }
    }

    private fun parseLanguage(q: Q): Command? {
        if (!q.anyIn(Lex.languageWords)) return null
        return when {
            q.anyIn(Lex.nepaliNames) -> Command.SetLanguage("ne")
            q.anyIn(Lex.englishNames) -> Command.SetLanguage("en")
            q.anyIn(Lex.autoNames) -> Command.SetLanguage("auto")
            else -> null
        }
    }

    private fun parseCall(q: Q): Command {
        val drop = Lex.callVerbs + Lex.weakCallVerbs + Lex.lagau + Lex.talkWords + Lex.stop + Lex.nepaliDo +
            setOf("back", "video", "voice")
        return Command.Call(q.raw(q.toks.filter { it.norm !in drop }))
    }

    private fun parseClick(q: Q): Command {
        val drop = Lex.clickVerbs + Lex.stop + Lex.nepaliDo + setOf("on", "button")
        val rest = q.toks.filter { it.norm !in drop }
        val target = q.raw(rest)
        val n = Norm.normalize(target)
        return when (n) {
            "back" -> Command.Global(GlobalKind.BACK)
            "home" -> Command.Global(GlobalKind.HOME)
            "recents" -> Command.Global(GlobalKind.RECENTS)
            else -> Command.ClickText(target)
        }
    }

    private fun parseType(q: Q): Command? {
        val toks = q.toks
        val en = toks.indexOfFirst { it.norm in Lex.typeVerbsEn }
        if (en >= 0) {
            val text = q.raw(toks.subList(en + 1, toks.size))
            return if (text.isNotBlank()) Command.TypeText(text) else null
        }
        val ne = toks.indexOfFirst { it.norm in Lex.typeVerbsNe }
        if (ne > 0) {
            var before = toks.subList(0, ne).toList()
            while (before.isNotEmpty() && (before.last().norm in Lex.stop || before.last().norm in setOf("yaha", "yahaa", "\u092F\u0939\u093E\u0901"))) {
                before = before.dropLast(1)
            }
            val text = q.raw(before)
            return if (text.isNotBlank()) Command.TypeText(text) else null
        }
        return null
    }

    private fun parseSms(q: Q): Command {
        val toks = q.toks
        val words = q.words
        val skip = Lex.smsNouns + Lex.sendVerbs + Lex.stop + Lex.nepaliDo
        val laiIdx = words.indexOfFirst { it == "lai" || it == "laai" || it == "\u0932\u093E\u0908" }
        val toIdx = words.indexOf("to")
        val sayIdx = words.indexOfFirst { it in Lex.sayWords }
        var name = ""
        var body = ""
        if (toIdx >= 0 && (laiIdx < 0 || toIdx < laiIdx)) {
            val nameEnd = if (sayIdx > toIdx) sayIdx else toks.size
            name = q.raw(toks.subList(toIdx + 1, nameEnd).filter { it.norm !in skip })
            if (sayIdx > toIdx) body = q.raw(toks.subList(sayIdx + 1, toks.size))
        } else if (laiIdx >= 0) {
            name = q.raw(toks.subList(0, laiIdx).filter { it.norm !in skip })
            val after = toks.subList(laiIdx + 1, toks.size)
            val cut = after.indexOfFirst { it.norm in Lex.sayWordsNe }
            body = if (cut >= 0) q.raw(after.subList(0, cut)) else q.raw(after.filter { it.norm !in skip })
        } else {
            val rest = toks.filter { it.norm !in Lex.smsNouns && it.norm !in Lex.sendVerbs && it.norm !in Lex.stop }
            name = rest.firstOrNull()?.raw ?: ""
            body = q.raw(rest.drop(1).filter { it.norm !in Lex.sayWords })
        }
        return Command.Sms(name.trim(), body.trim())
    }

    private fun panelFor(q: Q): PanelKind? = when {
        q.has("airplane mode", "flight mode", "aeroplane mode", "\u090F\u092F\u0930\u092A\u094D\u0932\u0947\u0928 \u092E\u094B\u0921", "\u092B\u094D\u0932\u093E\u0907\u091F \u092E\u094B\u0921") -> PanelKind.AIRPLANE
        q.has("battery saver", "power saving", "power saver", "battery saving") -> PanelKind.BATTERY_SAVER
        q.anyIn(Lex.hotspotWords) || q.has("mobile data", "internet data") -> PanelKind.HOTSPOT
        q.anyIn(Lex.wifiWords) -> PanelKind.WIFI
        q.anyIn(Lex.bluetoothWords) -> PanelKind.BLUETOOTH
        q.anyIn(Lex.locationWords) -> PanelKind.LOCATION
        q.has("brightness", "display settings", "screen brightness", "\u092C\u094D\u0930\u093E\u0907\u091F\u0928\u0947\u0938") -> PanelKind.DISPLAY
        else -> null
    }

    // ------------------------------------------------------------------------------------------------------------
    // time helpers (public so the brain can re-use them for follow-up answers)

    fun parseDuration(words: List<String>): Int {
        var total = 0
        for (i in words.indices) {
            val unit = Lex.unitSeconds[words[i]] ?: continue
            val prev = if (i > 0) words[i - 1] else ""
            if (unit == 3600 && prev in Lex.halfWords) {
                total += 1800
                continue
            }
            val n = Lex.numberValue(prev) ?: continue
            total += n * unit
        }
        return total
    }

    fun parseClock(words: List<String>): Pair<Int, Int>? {
        val clockRe = Regex("^(\\d{1,2})(?::(\\d{2}))?$")
        var hour = -1
        var minute = 0
        var at = -1
        for (i in words.indices) {
            val m = clockRe.find(words[i])
            if (m != null) {
                hour = m.groupValues[1].toInt()
                if (m.groupValues[2].isNotEmpty()) minute = m.groupValues[2].toInt()
                at = i
                break
            }
            val nw = Lex.numberWords[words[i]]
            if (nw != null && nw in 1..12 && i + 1 < words.size && words[i + 1] in Lex.clockMarkers) {
                hour = nw
                at = i
                break
            }
        }
        if (hour < 0 || hour > 24 || minute > 59) return null
        if (at > 0 && minute == 0 && words[at - 1] in Lex.sadhe) minute = 30
        val pm = words.any { it == "pm" || it in Lex.eveningWords }
        val am = words.any { it == "am" || it in Lex.morningWords }
        if (pm && hour < 12) {
            hour += 12
        } else if (am && hour == 12) {
            hour = 0
        } else if (!pm && !am && hour in 1..11) {
            val cal = Calendar.getInstance()
            val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            if (hour * 60 + minute <= nowMin && (hour + 12) * 60 + minute > nowMin) hour += 12
        }
        if (hour == 24) hour = 0
        return Pair(hour, minute)
    }
}
