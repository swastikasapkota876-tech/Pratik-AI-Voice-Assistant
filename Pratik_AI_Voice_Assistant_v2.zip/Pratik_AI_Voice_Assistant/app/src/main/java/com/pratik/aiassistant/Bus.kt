package com.pratik.aiassistant

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

enum class AssistantState { OFF, IDLE, LISTENING, THINKING, SPEAKING }

data class ChatLine(val fromUser: Boolean, val text: String, val time: Long = System.currentTimeMillis())

/** Tiny process-wide flags. */
object AppState {
    @Volatile
    var activityVisible: Boolean = false
}

/** Lets the foreground service talk to the UI without binding. All listener callbacks run on the main thread. */
object AssistantBus {
    interface Listener {
        fun onState(state: AssistantState) {}
        fun onChat(line: ChatLine) {}
        fun onPartial(text: String) {}
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile
    var state: AssistantState = AssistantState.OFF
        private set

    /** Only touch from the main thread. */
    val history = ArrayList<ChatLine>()

    fun add(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun remove(l: Listener) {
        listeners.remove(l)
    }

    fun setState(s: AssistantState) {
        state = s
        main.post { for (l in listeners) l.onState(s) }
    }

    fun chat(fromUser: Boolean, text: String) {
        val line = ChatLine(fromUser, text)
        main.post {
            history.add(line)
            if (history.size > 200) history.removeAt(0)
            for (l in listeners) l.onChat(line)
        }
    }

    fun partial(text: String) {
        main.post { for (l in listeners) l.onPartial(text) }
    }
}
