package com.pratik.aiassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), AssistantBus.Listener {

    private lateinit var statusText: TextView
    private lateinit var hintText: TextView
    private lateinit var partialText: TextView
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var toggleBtn: Button
    private lateinit var speakBtn: Button
    private lateinit var input: EditText
    private lateinit var settings: AppSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(buildUi())
    }

    override fun onStart() {
        super.onStart()
        AppState.activityVisible = true
        AssistantBus.add(this)
        chatBox.removeAllViews()
        for (line in AssistantBus.history) addBubble(line)
        onState(AssistantBus.state)
    }

    override fun onStop() {
        AssistantBus.remove(this)
        AppState.activityVisible = false
        super.onStop()
    }

    // ---- UI -----------------------------------------------------------------------------------------------------

    private fun buildUi(): View {
        val pad = Ui.dp(this, 16)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(pad, pad, pad, pad)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(pad + bars.left, pad + bars.top, pad + bars.right, pad + bars.bottom)
            insets
        }

        root.addView(Ui.text(this, "PRATIK AI", 30f, Ui.TEXT))
        root.addView(Ui.text(this, "Emotional multilingual voice assistant", 15f, Ui.MUTED))

        statusText = Ui.text(this, "Status: Off", 16f, Ui.MUTED)
        statusText.setPadding(0, Ui.dp(this, 12), 0, 0)
        root.addView(statusText)

        hintText = Ui.text(this, "", 13f, Ui.MUTED)
        root.addView(hintText)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        toggleBtn = Ui.button(this, "START ASSISTANT") { onToggle() }
        speakBtn = Ui.button(this, "SPEAK NOW") { onSpeakNow() }
        val lpA = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val lpB = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        buttons.addView(toggleBtn, lpA)
        buttons.addView(speakBtn, lpB)
        root.addView(buttons, Ui.matchWrap())

        val buttons2 = LinearLayout(this)
        buttons2.orientation = LinearLayout.HORIZONTAL
        val lpC = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val lpD = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        buttons2.addView(Ui.button(this, "ENABLE PHONE CONTROL") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lpC)
        buttons2.addView(Ui.button(this, "SETTINGS") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }, lpD)
        root.addView(buttons2, Ui.matchWrap())

        // quick command chips
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val examples = listOf(
            "Aama lai call gara", "Facebook khola", "Torch on", "Time kati bajyo?", "Battery kati cha?",
            "Volume badhau", "Home ja", "Who created you?"
        )
        for (ex in examples) {
            val b = Ui.button(this, ex) { sendTyped(ex) }
            b.textSize = 12f
            chips.addView(b)
        }
        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipScroll.addView(chips)
        root.addView(chipScroll, Ui.matchWrap())

        partialText = Ui.text(this, "", 14f, Ui.BLUE)
        partialText.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2))
        root.addView(partialText)

        chatBox = LinearLayout(this)
        chatBox.orientation = LinearLayout.VERTICAL
        chatScroll = ScrollView(this)
        chatScroll.addView(chatBox, Ui.matchWrap())
        root.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Type a command..."
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.maxLines = 2
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitInput()
                true
            } else false
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.button(this, "SEND") { submitInput() })
        root.addView(row, Ui.matchWrap())
        return root
    }

    private fun addBubble(line: ChatLine) {
        val tv = Ui.text(this, line.text, 15f, Ui.TEXT)
        tv.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8))
        tv.background = Ui.round(if (line.fromUser) Ui.USER_BUBBLE else Ui.BOT_BUBBLE, Ui.dp(this, 14).toFloat())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (line.fromUser) Gravity.END else Gravity.START
        lp.topMargin = Ui.dp(this, 6)
        lp.leftMargin = if (line.fromUser) Ui.dp(this, 48) else 0
        lp.rightMargin = if (line.fromUser) 0 else Ui.dp(this, 48)
        chatBox.addView(tv, lp)
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ---- bus callbacks ------------------------------------------------------------------------------------------

    override fun onState(state: AssistantState) {
        val (label, color) = when (state) {
            AssistantState.OFF -> Pair("Status: Off", Ui.MUTED)
            AssistantState.IDLE -> Pair("Status: Ready", Ui.ACCENT)
            AssistantState.LISTENING -> Pair("Status: Listening...", Ui.ACCENT)
            AssistantState.THINKING -> Pair("Status: Thinking...", Ui.WARN)
            AssistantState.SPEAKING -> Pair("Status: Speaking...", Ui.BLUE)
        }
        statusText.text = label
        statusText.setTextColor(color)
        val on = state != AssistantState.OFF
        toggleBtn.text = if (on) "STOP ASSISTANT" else "START ASSISTANT"
        speakBtn.isEnabled = on
        hintText.text = if (!on) "" else if (settings.wakeWordEnabled) "Say \"Hey ${settings.wakeWord}\" then your command" else "Always listening - say your command"
        if (!on) partialText.text = ""
    }

    override fun onChat(line: ChatLine) {
        addBubble(line)
    }

    override fun onPartial(text: String) {
        partialText.text = if (text.isBlank()) "" else "... $text"
    }

    // ---- actions ------------------------------------------------------------------------------------------------

    private fun onToggle() {
        if (AssistantService.running) AssistantService.stop(this) else ensurePermissionsThenStart()
    }

    private fun onSpeakNow() {
        if (AssistantService.running) AssistantService.listenNow(this)
    }

    private fun submitInput() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        sendTyped(text)
    }

    private fun sendTyped(text: String) {
        if (!AssistantService.running) {
            Toast.makeText(this, "Start the assistant first.", Toast.LENGTH_SHORT).show()
            return
        }
        AssistantService.sendText(this, text)
    }

    private fun runtimePermissions(): List<String> {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list
    }

    private fun ensurePermissionsThenStart() {
        val missing = runtimePermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            AssistantService.start(this)
        } else {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 100) return
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) {
            AssistantService.start(this)
        } else {
            Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_LONG).show()
        }
    }
}
