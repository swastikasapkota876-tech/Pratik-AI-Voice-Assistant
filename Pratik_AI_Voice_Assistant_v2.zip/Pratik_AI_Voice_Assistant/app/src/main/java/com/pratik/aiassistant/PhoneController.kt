package com.pratik.aiassistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "Tap to open" notification used when Android blocks a background app launch. */
object Notifier {
    private const val CHANNEL = "pratik_ai_actions"
    private var nextId = 2000

    @Synchronized
    fun tapToOpen(ctx: Context, title: String, intent: Intent) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Assistant actions", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(
                ctx, nextId, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText("Tap to open")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            nm.notify(nextId++, n)
            if (nextId > 2100) nextId = 2000
        } catch (e: Exception) {
            // notifications not permitted -> nothing more we can do
        }
    }
}

/**
 * Executes [Command]s on the phone. Every function returns the sentence the assistant should speak.
 * Safe to call from a worker thread.
 */
class PhoneController(private val ctx: Context, private val settings: AppSettings) {

    private var torchOn = false

    private fun has(permission: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    private fun a11y(): AssistantAccessibilityService? = AssistantAccessibilityService.instance

    fun needA11y(lang: Lang): String = t(
        lang,
        "Sir, please enable Phone Control (Accessibility) from the app first.",
        "Sir, pahila app bata 'Phone Control' (Accessibility) enable garnuhos."
    )

    // ------------------------------------------------------------------------------------------------------------
    // launching activities

    /**
     * Starts an activity. Android 10+ silently blocks launches from the background unless the app has a visible window,
     * the overlay permission, or is a bound accessibility service, so if none of those hold we also post a
     * tap-to-open notification.
     */
    fun launch(intent: Intent, label: String = ""): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val service = a11y()
        val contexts = ArrayList<Context>()
        if (service != null) contexts.add(service)
        contexts.add(ctx)
        var started = false
        for (c in contexts) {
            try {
                c.startActivity(intent)
                started = true
                break
            } catch (e: ActivityNotFoundException) {
                return false
            } catch (e: Exception) {
                // try the next context
            }
        }
        val mayBeBlocked = Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(ctx) &&
            service == null && !AppState.activityVisible
        if (mayBeBlocked || !started) Notifier.tapToOpen(ctx, if (label.isBlank()) "Pratik AI" else label, Intent(intent))
        return started
    }

    // ------------------------------------------------------------------------------------------------------------
    // apps & web

    fun openApp(name: String, lang: Lang): String {
        val hit = AppResolver.find(ctx, name)
            ?: return t(lang, "Sorry sir, I couldn't find an app called $name.", "Sir, '$name' naam ko app bhetina.")
        val intent = ctx.packageManager.getLaunchIntentForPackage(hit.pkg)
            ?: return t(lang, "Sorry sir, I can't open ${hit.label}.", "Sir, ${hit.label} kholna sakiena.")
        launch(intent, "Open ${hit.label}")
        return t(lang, "Opening ${hit.label}.", "Huss sir, ${hit.label} kholdai chu.")
    }

    fun webSearch(query: String, lang: Lang): String {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        launch(Intent(Intent.ACTION_VIEW, uri), "Search: $query")
        return t(lang, "Searching Google for $query.", "Huss sir, Google ma '$query' search gardai chu.")
    }

    fun youtube(query: String, lang: Lang): String {
        if (query.isBlank()) return openApp("youtube", lang)
        val app = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", query)
        if (!launch(app, "YouTube: $query")) {
            launch(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))),
                "YouTube: $query"
            )
        }
        return t(lang, "Searching YouTube for $query.", "Huss sir, YouTube ma '$query' khojdai chu.")
    }

    fun navigate(place: String, lang: Lang): String {
        if (place.isBlank()) return t(lang, "Where do you want to go?", "Sir, kaha jane ho?")
        val maps = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            .setPackage("com.google.android.apps.maps")
        if (!launch(maps, "Navigate: $place")) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))), "Map: $place")
        }
        return t(lang, "Getting directions to $place.", "Huss sir, $place ko route dekhaudai chu.")
    }

    fun panel(kind: PanelKind, lang: Lang): String {
        val (action, label) = when (kind) {
            PanelKind.WIFI ->
                Pair(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS, "Wi-Fi")
            PanelKind.BLUETOOTH -> Pair(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth")
            PanelKind.LOCATION -> Pair(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "Location")
            PanelKind.AIRPLANE -> Pair(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "Airplane mode")
            PanelKind.HOTSPOT -> Pair(Settings.ACTION_WIRELESS_SETTINGS, "Network")
            PanelKind.DISPLAY -> Pair(Settings.ACTION_DISPLAY_SETTINGS, "Display")
            PanelKind.BATTERY_SAVER -> Pair(Settings.ACTION_BATTERY_SAVER_SETTINGS, "Battery saver")
        }
        launch(Intent(action), label)
        return t(
            lang,
            "Opening $label settings. Android doesn't let apps flip this switch, so please tap it yourself.",
            "Huss sir, $label settings kholdai chu. Android le app lai yo switch aafai on/off garna didaina, hajur tap garnuhos."
        )
    }

    // ------------------------------------------------------------------------------------------------------------
    // calls & messages

    private fun dial(number: String): Boolean {
        val uri = Uri.fromParts("tel", number, null)
        if (has(Manifest.permission.CALL_PHONE)) {
            try {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.placeCall(uri, Bundle())
                return true
            } catch (e: Exception) {
                // fall through to the intent based routes
            }
            if (launch(Intent(Intent.ACTION_CALL, uri), "Call $number")) return true
        }
        launch(Intent(Intent.ACTION_DIAL, uri), "Dial $number")
        return false
    }

    private val numberRe = Regex("^\\+?\\d{3,15}$")

    fun call(target: String, lang: Lang): String {
        val compact = target.replace(" ", "").replace("-", "")
        val emergency = Lex.emergencyNumber(target)
        if (emergency != null) {
            dial(emergency)
            return t(lang, "Calling $target on $emergency.", "Huss sir, $target ($emergency) ma call gardai chu.")
        }
        if (numberRe.matches(compact)) {
            val ok = dial(compact)
            return if (ok) t(lang, "Calling $compact.", "Huss sir, $compact ma call gardai chu.")
            else t(lang, "I opened the dialer with $compact. Please press call.", "Sir, dialer ma $compact kholeko chu, call thichnuhos.")
        }
        if (!has(Manifest.permission.READ_CONTACTS)) {
            return t(lang, "Sir, I need Contacts permission to find $target.", "Sir, $target khojna Contacts permission chaiyo.")
        }
        val hits = ContactResolver.find(ctx, settings, target)
        if (hits.isEmpty()) {
            return t(
                lang,
                "Sorry sir, I couldn't find a contact named $target. You can add a nickname in Settings.",
                "Sir, '$target' naam ko saved contact bhetena. Settings ma nickname add garna sakinchha."
            )
        }
        val top = hits[0].score
        val tops = hits.filter { it.score == top }
        val distinct = tops.map { Norm.normalize(it.name) }.distinct()
        if (distinct.size > 1) {
            val names = tops.map { it.name }.distinct().take(3).joinToString(", ")
            return t(lang, "I found several matches: $names. Please say the full name.", "Sir, dherai match bhetiyo: $names. Pura naam bhannuhos.")
        }
        val chosen = tops[0]
        val ok = dial(chosen.number)
        return if (ok) t(lang, "Calling ${chosen.name}.", "Huss sir, ${chosen.name} lai call gardai chu.")
        else t(lang, "I opened the dialer for ${chosen.name}. Please press call.", "Sir, ${chosen.name} ko number dialer ma kholeko chu, call thichnuhos.")
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    fun sms(target: String, body: String, lang: Lang): String {
        val compact = target.replace(" ", "").replace("-", "")
        val number: String
        val display: String
        if (numberRe.matches(compact)) {
            number = compact
            display = compact
        } else {
            if (!has(Manifest.permission.READ_CONTACTS)) {
                return t(lang, "Sir, I need Contacts permission first.", "Sir, pahila Contacts permission dinuhos.")
            }
            val hits = ContactResolver.find(ctx, settings, target)
            if (hits.isEmpty()) {
                return t(lang, "Sorry sir, I couldn't find $target in your contacts.", "Sir, '$target' contact ma bhetena.")
            }
            val top = hits[0].score
            val tops = hits.filter { it.score == top }
            if (tops.map { Norm.normalize(it.name) }.distinct().size > 1) {
                val names = tops.map { it.name }.distinct().take(3).joinToString(", ")
                return t(lang, "Several contacts match: $names. Please say the full name.", "Sir, dherai match bhetiyo: $names. Pura naam bhannuhos.")
            }
            number = tops[0].number
            display = tops[0].name
        }

        if (has(Manifest.permission.SEND_SMS)) {
            try {
                val sm: SmsManager = smsManager()
                sm.sendMultipartTextMessage(number, null, sm.divideMessage(body), null, null)
                return t(lang, "Message sent to $display.", "Huss sir, $display lai message pathaiyo.")
            } catch (e: Exception) {
                // fall back to the composer below
            }
        }
        val compose = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", body)
        launch(compose, "Message to $display")
        return t(
            lang,
            "I opened the message to $display. Please press send.",
            "Sir, $display ko message tayar chha, send thichnuhos."
        )
    }

    // ------------------------------------------------------------------------------------------------------------
    // alarms

    fun alarm(hour: Int, minute: Int, lang: Lang): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Pratik AI")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val shown = format12(hour, minute)
        if (!launch(intent, "Alarm $shown")) {
            return t(lang, "Sorry sir, no clock app can set alarms.", "Sir, alarm set garne clock app bhetiena.")
        }
        return t(lang, "Alarm set for $shown.", "Huss sir, $shown ko alarm set gare.")
    }

    fun timer(seconds: Int, lang: Lang): String {
        val secs = seconds.coerceIn(1, 86400)
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Pratik AI")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val human = humanDuration(secs, lang)
        if (!launch(intent, "Timer $human")) {
            return t(lang, "Sorry sir, no clock app can set timers.", "Sir, timer set garne clock app bhetiena.")
        }
        return t(lang, "Timer set for $human.", "Huss sir, $human ko timer set gare.")
    }

    private fun format12(hour: Int, minute: Int): String {
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        return String.format(Locale.ENGLISH, "%d:%02d %s", h12, minute, if (hour < 12) "AM" else "PM")
    }

    private fun humanDuration(secs: Int, lang: Lang): String {
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val s = secs % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add(if (lang == Lang.NE) "$h ghanta" else "$h hour" + if (h > 1) "s" else "")
        if (m > 0) parts.add(if (lang == Lang.NE) "$m minute" else "$m minute" + if (m > 1) "s" else "")
        if (s > 0 || parts.isEmpty()) parts.add(if (lang == Lang.NE) "$s second" else "$s second" + if (s != 1) "s" else "")
        return parts.joinToString(" ")
    }

    // ------------------------------------------------------------------------------------------------------------
    // hardware

    fun flashlight(on: Boolean, lang: Lang): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(cid)
                val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = ch.get(CameraCharacteristics.LENS_FACING)
                if (flash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                t(lang, "Sorry sir, this phone has no flashlight.", "Sir, yo phone ma torch chaina.")
            } else {
                cm.setTorchMode(id, on)
                torchOn = on
                if (on) t(lang, "Flashlight on.", "Huss sir, torch balyo.")
                else t(lang, "Flashlight off.", "Huss sir, torch nibhayo.")
            }
        } catch (e: Exception) {
            t(lang, "Sorry sir, I couldn't control the flashlight.", "Sir, torch control garna sakiena.")
        }
    }

    fun volume(mode: VolumeMode, percent: Int, lang: Lang): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(stream)
        try {
            when (mode) {
                VolumeMode.UP -> am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                VolumeMode.DOWN -> am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                VolumeMode.MUTE -> am.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                VolumeMode.UNMUTE -> am.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                VolumeMode.MAX -> am.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI)
                VolumeMode.SET -> am.setStreamVolume(stream, Math.round(percent.coerceIn(0, 100) / 100f * max), AudioManager.FLAG_SHOW_UI)
                VolumeMode.SHOW -> am.adjustStreamVolume(stream, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
            }
        } catch (e: Exception) {
            return t(lang, "Sorry sir, I couldn't change the volume.", "Sir, volume change garna sakiena.")
        }
        return when (mode) {
            VolumeMode.UP -> t(lang, "Volume up.", "Huss sir, volume badhayo.")
            VolumeMode.DOWN -> t(lang, "Volume down.", "Huss sir, volume ghatayo.")
            VolumeMode.MUTE -> t(lang, "Muted.", "Huss sir, mute gare.")
            VolumeMode.UNMUTE -> t(lang, "Unmuted.", "Huss sir, unmute gare.")
            VolumeMode.MAX -> t(lang, "Volume at maximum.", "Huss sir, volume maximum gare.")
            VolumeMode.SET -> t(lang, "Volume set to $percent percent.", "Huss sir, volume $percent percent gare.")
            VolumeMode.SHOW -> t(lang, "Here is the volume slider.", "Sir, volume slider dekhaiyeko chu.")
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // information

    fun tellTime(lang: Lang): String {
        val now = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
        return t(lang, "It's $now.", "Sir, ahile $now bhayo.")
    }

    fun tellDate(lang: Lang): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
        return t(lang, "Today is $now.", "Sir, aaja $now ho.")
    }

    fun tellBattery(lang: Lang): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        if (level < 0 || scale <= 0) return t(lang, "Sorry sir, I can't read the battery.", "Sir, battery padhna sakiena.")
        val pct = level * 100 / scale
        return if (charging) t(lang, "Battery is at $pct percent and charging.", "Sir, battery $pct percent cha, charge hudai cha.")
        else t(lang, "Battery is at $pct percent.", "Sir, battery $pct percent cha.")
    }

    // ------------------------------------------------------------------------------------------------------------
    // accessibility based control

    fun global(kind: GlobalKind, lang: Lang): String {
        val svc = a11y()
        if (svc == null) {
            if (kind == GlobalKind.HOME) {
                launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), "Home")
                return t(lang, "Going home.", "Huss sir, home screen ma lagdai chu.")
            }
            return needA11y(lang)
        }
        val ok = svc.global(kind)
        if (!ok) return t(lang, "Sorry sir, that isn't supported on this phone.", "Sir, yo phone ma yo action support chaina.")
        return when (kind) {
            GlobalKind.HOME -> t(lang, "Going home.", "Huss sir, home screen ma lagdai chu.")
            GlobalKind.BACK -> t(lang, "Going back.", "Huss sir, back gaye.")
            GlobalKind.RECENTS -> t(lang, "Showing recent apps.", "Huss sir, recent apps dekhaudai chu.")
            GlobalKind.NOTIFICATIONS -> t(lang, "Opening notifications.", "Huss sir, notification kholdai chu.")
            GlobalKind.QUICK_SETTINGS -> t(lang, "Opening quick settings.", "Huss sir, quick settings kholdai chu.")
            GlobalKind.LOCK -> t(lang, "Locking the screen.", "Huss sir, screen lock gare.")
            GlobalKind.SCREENSHOT -> t(lang, "Taking a screenshot.", "Huss sir, screenshot line lagyo.")
        }
    }

    fun click(text: String, lang: Lang): String {
        val svc = a11y() ?: return needA11y(lang)
        return when (svc.clickByText(text)) {
            AssistantAccessibilityService.ClickResult.CLICKED -> t(lang, "Tapped $text.", "Huss sir, $text thichey.")
            AssistantAccessibilityService.ClickResult.NO_SCREEN -> t(lang, "I can't see the screen right now.", "Sir, ahile screen dekhna sakiena.")
            AssistantAccessibilityService.ClickResult.NOT_FOUND -> t(lang, "I couldn't find $text on the screen.", "Sir, screen ma '$text' bhetiena.")
        }
    }

    fun scroll(down: Boolean, lang: Lang): String {
        val svc = a11y() ?: return needA11y(lang)
        val ok = svc.scroll(down)
        return if (ok) t(lang, if (down) "Scrolling down." else "Scrolling up.", if (down) "Huss sir, tala scroll gare." else "Huss sir, mathi scroll gare.")
        else t(lang, "Sorry sir, I couldn't scroll here.", "Sir, yaha scroll garna sakiena.")
    }

    fun type(text: String, lang: Lang): String {
        val svc = a11y() ?: return needA11y(lang)
        return when (svc.typeText(text)) {
            AssistantAccessibilityService.TypeResult.TYPED -> t(lang, "Typed.", "Huss sir, lekhiyo.")
            AssistantAccessibilityService.TypeResult.NO_FIELD -> t(lang, "Tap a text box first, then ask me to type.", "Sir, pahila text box ma thichnuhos, ani lekhna bhannuhos.")
            AssistantAccessibilityService.TypeResult.PASSWORD -> t(lang, "Sorry sir, I never type into password fields.", "Sir, ma password field ma kahile lekhdina.")
            AssistantAccessibilityService.TypeResult.NO_SCREEN -> t(lang, "I can't see the screen right now.", "Sir, ahile screen dekhna sakiena.")
        }
    }

    /** Raw visible text (used by ReadScreen and DescribeScreen). Empty string when nothing readable. */
    fun screenText(max: Int): String? = a11y()?.readScreen(max)

    fun readScreen(lang: Lang): String {
        val text = screenText(1200) ?: return needA11y(lang)
        if (text.isBlank()) return t(lang, "I can't find any readable text on this screen.", "Sir, yo screen ma padhna milne text bhetiena.")
        return text
    }
}
