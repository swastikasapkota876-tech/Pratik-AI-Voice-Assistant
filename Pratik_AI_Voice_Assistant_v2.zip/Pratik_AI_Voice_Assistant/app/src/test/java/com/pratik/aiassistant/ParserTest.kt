package com.pratik.aiassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure-JVM tests for the multilingual command parser and wake-word logic. Run: ./gradlew test */
class ParserTest {
    private val p = IntentParser()

    @Test fun callInRomanNepali() = assertEquals(Command.Call("Aama"), p.parse("Aama lai call gara"))
    @Test fun callInEnglish() = assertEquals(Command.Call("mom"), p.parse("call mom"))
    @Test fun callInDevanagari() =
        assertEquals(Command.Call("\u0906\u092E\u093E"), p.parse("\u0906\u092E\u093E \u0932\u093E\u0908 \u0915\u0932 \u0917\u0930"))

    @Test fun mentioningMotherDoesNotCall() = assertEquals(Command.Unknown, p.parse("my mother is at home today"))
    @Test fun openApp() = assertEquals(Command.OpenApp("Facebook"), p.parse("Facebook khola"))
    @Test fun back() = assertEquals(Command.Global(GlobalKind.BACK), p.parse("Back ja"))
    @Test fun creator() = assertEquals(Command.CreatorQuestion, p.parse("Who created you?"))
    @Test fun impersonation() = assertEquals(Command.ImpersonationClaim, p.parse("maile timilai banaye"))
    @Test fun deleteImportant() = assertEquals(Command.Delete(true), p.parse("delete important file"))
    @Test fun torchOff() = assertEquals(Command.Flashlight(false), p.parse("torch band gara"))
    @Test fun volumePercent() = assertEquals(Command.Volume(VolumeMode.SET, 50), p.parse("volume 50 percent"))
    @Test fun alarm() = assertEquals(Command.SetAlarm(7, 30), p.parse("set alarm for 7:30 am"))
    @Test fun timer() = assertEquals(Command.SetTimer(300), p.parse("5 minute ko timer lagau"))
    @Test fun smsEnglish() =
        assertEquals(Command.Sms("mom", "I will be late"), p.parse("send message to mom saying I will be late"))
    @Test fun smsNepali() =
        assertEquals(Command.Sms("aama", "ma ghar aauchu"), p.parse("aama lai ma ghar aauchu bhanera message pathau"))
    @Test fun panel() = assertEquals(Command.Panel(PanelKind.WIFI), p.parse("wifi on gara"))
    @Test fun click() = assertEquals(Command.ClickText("Send"), p.parse("click Send"))
    @Test fun youtube() = assertEquals(Command.YouTube("lofi song"), p.parse("youtube ma lofi song chalau"))
    @Test fun battery() = assertEquals(Command.TellBattery, p.parse("phone ma battery kati cha"))
    @Test fun questionsFallThrough() = assertEquals(Command.Unknown, p.parse("what is the capital of nepal"))

    @Test fun wakeWordFound() {
        val r = WakeWord.strip("Hey Pratik call mom", "pratik")
        assertTrue(r.found)
        assertEquals("call mom", r.rest)
    }

    @Test fun wakeWordMissing() = assertFalse(WakeWord.strip("call mom", "pratik").found)
    @Test fun wakeWordMisheardSpelling() = assertTrue(WakeWord.strip("prateek open youtube", "pratik").found)
}
